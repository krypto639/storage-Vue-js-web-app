/* globals localStorage */

// FEATURE 13. Provide default values
const STORAGE_KEY = 'storageManagerMobileAndWeb'

// FEATURE 2. Add a part
class Gear { // eslint-disable-line no-unused-vars
  // FEATURE 11. A calculation within a part
  // NOT IMPLEMENTED :-(
  constructor (newId, newTitle, newDesc, newQuantity, newType, newValue, newCondition) {
    this.id = newId
    this.title = newTitle
    this.desc = newDesc //Feature 13. Use Title with a standard description
    this.quantity = newQuantity
    this.type = newType
    this.value = newValue
    this.condition = newCondition
    this.checkedOut = false // FEATURE 13. Provide default values
  }
}

// FEATURE 1. Create a whole that acts as a Facade for parts
class Storage { // eslint-disable-line no-unused-vars
  constructor () {
    this.allMyGear = []
    // the following 3 attibutes are used to support editing a task
    this.editedGear = null
    this.editedGearIndex = null
    this.beforeEditTitle = ''
    this.beforeEditDesc = ''
    this.beforeEditQuantity = null
    this.beforeEditType = ''
    this.beforeEditValue = null
    this.beforeEditCondition = ''
    this.beforeEditCheckedOut = null
  }

  // FEATURE 15. Get all parts
  getAllGear () {
    return this.allMyGear
  }

  // FEATURE 12. A calculation across many parts ! a weak example !
  // FEATURE 4. Filter parts
  getStoredGear () {
    return this.allMyGear.filter(gear => !gear.checkedOut)
  }

  // FEATURE 12. A calculation across many parts ! a weak example !
  // FEATURE 4. Filter parts
  getCheckedOutGear () {
    return this.allMyGear.filter(function (gear) {
      return gear.checkedOut
    })
  }
  //Value > a 
  //Value <b
  // FEATURE 4. Filter parts
  filterGearValue (a, b) {
    var AllResults = this.allMyGear.filter(gear => gear.value>a && gear.value<b)
    var titlesOfMatchingGear = []
    for (var i=0; i<AllResults.length; i++){
      titlesOfMatchingGear.push(AllResults[i].title)
    }
    return titlesOfMatchingGear
  }

  // FEATURE 4. Filter parts
  filterGearQuantity (a, b) {
    var AllResults = this.allMyGear.filter(gear => gear.quantity>a && gear.quantity<b)
    var titlesOfMatchingGear = []
    for (var i=0; i<AllResults.length; i++){
      titlesOfMatchingGear.push(AllResults[i].title)
    }
    return titlesOfMatchingGear
  }

  // FEATURE 7. Load all parts from LocalStorage
  load () {
    // FEATURE 13. Provide default values
    return JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]')
  }

  //  FEATURE 6. Save all parts to LocalStorage
  save () {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(this.allMyGear))
  }

  // FEATURE 2. Add a part
  addGear (newTitle, newQuantity, newType, newValue, newCondition) {
    newTitle = newTitle.trim()
    newQuantity = newQuantity
    newType = newType.trim()
    newValue = newValue
    newCondition = newCondition.trim()
    //Feature 10. Validate Inputs
    if (!newTitle /*||!newQuantity || !newType || !newValue ||!newCondition*/) {
      return
    }else if(!newQuantity || isNaN(newQuantity)==true || typeof(newQuantity)==='string'){
      return
    }else if(!newType){
      return
    }else if(!newValue || isNaN(newValue)==true || typeof(newValue)==='string'){
      return
    }else if(!newCondition){
      return
    }
    // FEATURE 13. Provide default values
    const newId = this.allMyGear.length + 1
    const newDesc = "A "+newTitle+" avaliable for check out from storage"
    
    /*if(newDesc ==""){
      const newDesc = "A "+newTitle+" avaliable for checkOut from storage"
      }else{
        newDesc = newDesc.trim()
      }*/
    /*if(newCondition ==""){
    const newCondition = "New"
    }*/
    const newGear = new Gear(newId, newTitle, newDesc, newQuantity, newType,newValue, newCondition)
    this.allMyGear.push(newGear)
  }

  // FEATURE 12. A calculation across many parts
  gearCountCheckedOut () {
    var storedGearCount = this.getStoredGear().length
    var allGearCount = this.allMyGear.length
    return allGearCount-storedGearCount
  }

  // FEATURE 12. A calculation across many parts
  allGearReturned () {
    return this.gearCountCheckedOut() === 0
  }

  setAllGearStored () {
    this.allMyGear.forEach(function (gear) {
      gear.checkedOut = false
    })
  }

  // FEATURE 5. Delete a selected part
  removeGear (targetGearTitle) {
    const index = this.allMyGear.findIndex(gear => gear.title === targetGearTitle)
    this.allMyGear.splice(index, 1)
  }

  // FEATURE 8. Update/edit a part
  // copies the task and title 
  startEditingGear (gear) {
    this.beforeEditTitle = gear.title
    this.beforeEditDesc = gear.desc
    this.beforeEditQuantity = gear.quantity
    this.beforeEditType = gear.type
    this.beforeEditValue = gear.value
    this.beforeEditCondition = gear.condition
    this.beforeEditCheckedOut = gear.checkedOut
    this.editedGear = gear
  }

  // FEATURE 8. Update/edit a part
  doneEditing (gear) {
    // FEATURE 10. Validate inputs
    
    if (!gear) {
      return
    }
    this.editedGear = null
    gear.title = gear.title.trim()
    if (gear.title==''||!gear.title) {
      //this.removeGear(gear)
      gear.title = this.beforeEditTitle
    }

    gear.desc = gear.desc.trim()
    if (gear.desc==''||!gear.desc) {
      //this.removeGear(gear)
      gear.desc = this.beforeEditDesc
    }

    if (!gear.quantity || isNaN(gear.quantity)==true || typeof(gear.quantity)==='string'||gear.quantity===undefined) {
      //this.removeGear(gear)
      gear.quantity = this.beforeEditQuantity
    }

    gear.gearType = gear.gearType.trim()
    if (gear.gearType===''||!gear.gearType) {
      //this.removeGear(gear)
      gear.gearType = this.beforeEditType
    }

    if (!gear.value || isNaN(gear.value)==true || typeof(gear.value)==='string'||gear.value===undefined) {
      //this.removeGear(gear)
      gear.value = this.beforeEditValue
    }

    gear.condition = gear.condition.trim()
    if (gear.condition==''||!gear.condition) {
      //this.removeGear(gear)
      gear.condition = this.beforeEditCondition
    }

    if (gear.checkedOut==''||!gear.checkedOut|| typeof gear.checkedOut !=='boolean') {
      //this.removeGear(gear)
      gear.checkedOut = this.beforeEditCheckedOut
    }
  }

  // FEATURE 9. Discard /revert edits to a part
  cancelEditingGear (gear) {
    this.editedGear = null
    gear.title = this.beforeEditTitle
    gear.desc = this.beforeEditDesc
    gear.quantity = this.beforeEditQuantity
    gear.type = this.beforeEditType
    gear.value = this.beforeEditValue
    gear.condition = this.beforeEditCondition
    gear.checkedOut = this.beforeEditCheckedOut
  }

  // FEATURE 5. Delete a selected part
  removeGearCheckedOut () {
    this.allMyGear = this.getStoredGear ()
  }

  // FEATURE 3. Sort parts
  sortGear (field) {
    if(field==='Title'){
    this.allMyGear.sort(function (a, b) {
      if (a.title < b.title) {
        return -1
      }
      if (a.title > b.title) {
        return 1
      }
      // a must be equal to b
      return 0
    })
  }

  if(field==='Quantity'){
    this.allMyGear.sort(function (a, b) {
      if (a.quantity < b.quantity) {
        return -1
      }
      if (a.quantity > b.quantity) {
        return 1
      }
      // a must be equal to b
      return 0
    })
  }

  
  if(field==='Type'){
    this.allMyGear.sort(function (a, b) {
      if (a.type < b.type) {
        return -1
      }
      if (a.type > b.type) {
        return 1
      }
      // a must be equal to b
      return 0
    })
  }

  
  if(field==='Value'){
    this.allMyGear.sort(function (a, b) {
      if (a.value < b.value) {
        return -1
      }
      if (a.value > b.value) {
        return 1
      }
      // a must be equal to b
      return 0
    })
  }

  if(field==='Condition'){
    this.allMyGear.sort(function (a, b) {
      if (a.condition < b.condition) {
        return -1
      }
      if (a.condition > b.condition) {
        return 1
      }
      // a must be equal to b
      return 0
    })
  }

}

  // FEATURE 14. Find a part given a search criterion
  // NOTE: finds only FIRST match!
  findGear (targetTitle) {
    return this.allMyGear.find((gear) => gear.title === targetTitle)
  }

  // FEATURE 12. Calculate the Sum of the Whole
  calculateWhole(field){
    var totalValueOfAllGear=0
    var totalQuanatityOfGear=0
    if(field=='Value'){
      for(var i=0; i<this.allMyGear.length; i++){
        totalValueOfAllGear += this.allMyGear[i].value
      }
        return totalValueOfAllGear
    }

    if(field=='Qunatity'){
      for(var i=0; i<this.allMyGear.length; i++){
        totalQuanatityOfGear += this.allMyGear[i].quantity
      }
        return totalQuanatityOfGear
    }
  
  }

  // FEATURE 11. Calculate the Sum of a Part
  calculatePercentage(field){
    var totalValueOfAllGear=0
    var totalQuanatityOfAllGear=0
    var gearPercentageQuantity
    var gearPercentageValue
    var gearTitleAndPercentage = []
    
    if(field=='Value'){
      var totalValueOfAllGear = this.calculateWhole('Value')
      
      for(var i=0; i<this.allMyGear.length; i++){
        var onePercentOfWhole = totalValueOfAllGear/100
        gearPercentageValue = this.allMyGear[i].value / onePercentOfWhole
        gearTitleAndPercentage.push([this.allMyGear[i].title, gearPercentageValue])
      }
        return gearTitleAndPercentage
    }

    if(field=='Quantity'){
      var totalQuanatityOfAllGear = this.calculateWhole('Qunatity')
      
      for(var i=0; i<this.allMyGear.length; i++){
        var onePercentOfWhole = totalQuanatityOfAllGear/100
        gearPercentageQuantity = this.allMyGear[i].quantity / onePercentOfWhole
        gearTitleAndPercentage.push([this.allMyGear[i].title, gearPercentageQuantity])
      }
        return gearTitleAndPercentage
    }
  }
  
  

}

