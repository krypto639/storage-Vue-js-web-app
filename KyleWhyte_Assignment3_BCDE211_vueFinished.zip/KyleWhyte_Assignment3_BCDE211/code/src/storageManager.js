"use strict";
var gearTypeOptions;
(function (gearTypeOptions) {
    gearTypeOptions["Measurement"] = "Measurement tool";
    gearTypeOptions["Painting"] = "Painting";
    gearTypeOptions["Cutting_Tools"] = "Saws, Blades and Cutting Tools";
    gearTypeOptions["Hammering_Tools"] = "Hammering Tools";
    gearTypeOptions["Concreting"] = "Concreting";
    gearTypeOptions["Glues"] = "Glues, Adhesive";
    gearTypeOptions["Piping"] = "Piping and Plumbing";
    gearTypeOptions["Walling"] = "Walling";
    gearTypeOptions["Roofing"] = "Roofing";
    gearTypeOptions["Electrical"] = "Electrical Tools and Equipment";
    gearTypeOptions["Safety_Equipment"] = "Safety Equipment";
    gearTypeOptions["Automative_Tools"] = "Automative Tools";
    gearTypeOptions["Tightening_Tools"] = "Bolts and Wrenches";
    gearTypeOptions["Binding_Tools"] = "Screws, Nails, Joins";
    gearTypeOptions["Miscellaneous"] = "Miscellaneous";
    gearTypeOptions["Undefined"] = "undefined";
})(gearTypeOptions || (gearTypeOptions = {}));
/* globals localStorage */
// FEATURE 13. Provide default values
const STORAGE_KEY = 'storageManagerMobileAndWeb';
// FEATURE 2. Add a part
class Gear {
    constructor(newId, newTitle, newDesc, newQuantity, newType, newValue, newCondition) {
        this.id = newId;
        this.title = newTitle;
        this.desc = newDesc; //Feature 13. Use Title with a standard description
        this.quantity = newQuantity;
        this.gearType = newType;
        this.value = newValue;
        this.condition = newCondition;
        this.checkedOut = false; // FEATURE 13. Provide default values
    }
}
// FEATURE 1. Create a whole that acts as a Facade for parts
class Store {
    constructor() {
        this.allMyGear = [];
        // the following 3 attibutes are used to support editing a task
        this.editedGear = null;
        this.editedGearIndex = 0;
        this.beforeEditTitle = '';
        this.beforeEditDesc = '';
        this.beforeEditQuantity = 0;
        this.beforeEditType = gearTypeOptions.Undefined;
        this.beforeEditValue = 0.00;
        this.beforeEditCondition = '';
        this.beforeEditCheckedOut = false;
    }

    //Value > a 
    //Value <b
    // FEATURE 4. Filter parts
    filterGearValue(a, b) {
        var AllResults = this.allMyGear.filter(gear => gear.value > a && gear.value < b);
        var titlesOfMatchingGear = [];
        //for (var i=0; i<AllResults.length; i++){
        for (var gear of AllResults) {
            titlesOfMatchingGear.push(gear.title);
        }
        return titlesOfMatchingGear;
    }
    // FEATURE 4. Filter parts
    filterGearQuantity(a, b) {
        var AllResults = this.allMyGear.filter(gear => gear.quantity > a && gear.quantity < b);
        var titlesOfMatchingGear = [];
        //for (var i=0; i<AllResults.length; i++){
        for (var gear of AllResults) {
            titlesOfMatchingGear.push(gear.title);
        }
        return titlesOfMatchingGear;
    }
    // FEATURE 7. Load all parts from LocalStorage
    load() {
        // FEATURE 13. Provide default values
        return JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    }
    //  FEATURE 6. Save all parts to LocalStorage
    save() {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(this.allMyGear));
    }
    // FEATURE 2. Add a part
    addGear(newTitle, newQuantity, newType, newValue, newCondition) {
        newTitle = newTitle.trim();
        newQuantity = newQuantity;
        newType = newType.trim()
        newValue = newValue;
        newCondition = newCondition.trim();
        //Feature 10. Validate Inputs
        if (!newTitle /*||!newQuantity || !newType || !newValue ||!newCondition*/) {
            return;
        }
        else if (!newQuantity || isNaN(newQuantity) == true || typeof (newQuantity) === 'string') {
            return;
        }
        else if (!newType || newType=="") {
            return;
        }
        else if (!newValue || isNaN(newValue) == true || typeof (newValue) === 'string') {
            return;
        }
        else if (!newCondition) {
            return;
        }
        // FEATURE 13. Provide default values
        const newId = this.allMyGear.length + 1;
        const newDesc = "A " + newTitle + " avaliable for check out from storage";
        /*if(newDesc ==""){
          const newDesc = "A "+newTitle+" avaliable for checkOut from storage"
          }else{
            newDesc = newDesc.trim()
          }*/
        /*if(newCondition ==""){
        const newCondition = "New"
        }*/
        const newGear = new Gear(newId, newTitle, newDesc, newQuantity, newType, newValue, newCondition);
        this.allMyGear.push(newGear);
    }

    // FEATURE 15. Get all parts
    getAllGear() {
        return this.allMyGear;
    }
    // FEATURE 12. A calculation across many parts ! a weak example !
    // FEATURE 4. Filter parts
    //ReturnType
    getStoredGear() {
        return this.allMyGear.filter(gear => !gear.checkedOut);
    }
    // FEATURE 12. A calculation across many parts ! a weak example !
    // FEATURE 4. Filter parts
    getCheckedOutGear() {
        return this.allMyGear.filter(function (gear) {
            return gear.checkedOut;
        });
    }

    getCheckedOutGearCount() {
        return this.getCheckedOutGear().length;
    }

    // FEATURE 12. A calculation across many parts
    //previously stillToBeReturne
    getStoredGearCount() {
        return this.getStoredGear().length;
    }
    // FEATURE 12. A calculation across many parts
    //previously getAllStored()
    isAllGearReturned() {
        return this.getStoredGearCount() === this.allMyGear.length;
    }
    setAllGearStored() {
        this.allMyGear.forEach(function (gear) {
            gear.checkedOut = false;
        });
    }
    // FEATURE 5. Delete a selected part
    removeGear(targetGearTitle) {
        const index = this.allMyGear.findIndex(gear => gear.title === targetGearTitle);
        this.allMyGear.splice(index, 1);
    }
    // FEATURE 8. Update/edit a part
    // copies the task and title 
    startEditingGear(gear) {
        this.beforeEditTitle = gear.title;
        this.beforeEditDesc = gear.desc;
        this.beforeEditQuantity = gear.quantity;
        this.beforeEditType = gear.gearType;
        this.beforeEditValue = gear.value;
        this.beforeEditCondition = gear.condition;
        this.beforeEditCheckedOut = gear.checkedOut;
        this.editedGear = gear;
    }
    // FEATURE 8. Update/edit a part
    doneEditing(gear) {
        // FEATURE 10. Validate inputs
        if (!gear) {
            return;
        }
        this.editedGear = null;
        gear.title = gear.title.trim();
        if (gear.title == '' || !gear.title) {
            //this.removeGear(gear)
            gear.title = this.beforeEditTitle;
        }
        gear.desc = gear.desc.trim();
        if (gear.desc == '' || !gear.desc) {
            //this.removeGear(gear)
            gear.desc = this.beforeEditDesc;
        }
        if (!gear.quantity || isNaN(gear.quantity) == true || typeof(gear.quantity) === 'string' /*|| gear.quantity*/) {
            //this.removeGear(gear)
            gear.quantity = this.beforeEditQuantity;
        }
        // gear.gearType = gear.gearType.trim()
        if (gear.gearType==''||gear.gearType==undefined) {
          //this.removeGear(gear)
          gear.gearType = this.beforeEditType
        }
        if (!gear.value || isNaN(gear.value) == true || typeof (gear.value) === 'string' /*|| gear.value*/) {
            //this.removeGear(gear)
            gear.value = this.beforeEditValue;
        }
        gear.condition = gear.condition.trim();
        if (gear.condition == '' || !gear.condition) {
            //this.removeGear(gear)
            gear.condition = this.beforeEditCondition;
        }
        if (/*gear.checkedOut ||*/ !gear.checkedOut || typeof gear.checkedOut !== 'boolean') {
            //this.removeGear(gear)
            gear.checkedOut = this.beforeEditCheckedOut;
        }
    }
    // FEATURE 9. Discard /revert edits to a part
    cancelEditingGear(gear) {
        this.editedGear = null;
        gear.title = this.beforeEditTitle;
        gear.desc = this.beforeEditDesc;
        gear.quantity = this.beforeEditQuantity;
        gear.gearType = this.beforeEditType;
        gear.value = this.beforeEditValue;
        gear.condition = this.beforeEditCondition;
        gear.checkedOut = this.beforeEditCheckedOut;
    }
    // FEATURE 5. Delete a selected part
    removeGearCheckedOut() {
        this.allMyGear = this.getStoredGear();
    }
    // FEATURE 3. Sort parts
    sortGear(field) {
        if (field === 'Title') {
            this.allMyGear.sort(function (a, b) {
                if (a.title < b.title) {
                    return -1;
                }
                if (a.title > b.title) {
                    return 1;
                }
                // a must be equal to b
                return 0;
            });
        }
        if (field === 'Quantity') {
            this.allMyGear.sort(function (a, b) {
                if (a.quantity < b.quantity) {
                    return -1;
                }
                if (a.quantity > b.quantity) {
                    return 1;
                }
                //sort by title if field is equal
                if (a.title < b.title) {
                    return -1;
                }
                if (a.title > b.title) {
                    return 1;
                }
                // a must be equal to b
                return 0;
            });
        }
        if (field === 'Type') {
            this.allMyGear.sort(function (a, b) {
                if (a.gearType < b.gearType) {
                    return -1;
                }
                if (a.gearType > b.gearType) {
                    return 1;
                }
                //sort by title if field is equal
                if (a.title < b.title) {
                    return -1;
                }
                if (a.title > b.title) {
                    return 1;
                }
                // a must be equal to b
                return 0;
            });
        }
        if (field === 'Value') {
            this.allMyGear.sort(function (a, b) {
                if (a.value < b.value) {
                    return -1;
                }
                if (a.value > b.value) {
                    return 1;
                }
                //sort by title if field is equal
                if (a.title < b.title) {
                    return -1;
                }
                if (a.title > b.title) {
                    return 1;
                }
                // a must be equal to b
                return 0;
            });
        }
        if (field === 'Condition') {
            this.allMyGear.sort(function (a, b) {
                if (a.condition < b.condition) {
                    return -1;
                }
                if (a.condition > b.condition) {
                    return 1;
                }
                //sort by title if field is equal
                if (a.title < b.title) {
                    return -1;
                }
                if (a.title > b.title) {
                    return 1;
                }
                // a must be equal to b
                return 0;
            });
        }
    }
    // FEATURE 14. Find a part given a search criterion
    // NOTE: finds only FIRST match!
    findGear(targetTitle) {
        return this.allMyGear.find((gear) => gear.title === targetTitle);
    }
   
    calculateTotalValue() {
        var totalValueOfAllGear = 0;
        for (var gear of this.allMyGear) {
            totalValueOfAllGear += gear.value;
        }
        return totalValueOfAllGear;
    }
    calculateTotalQuantity() {
        var totalQuanatityOfGear = 0;
        //for(var i=0; i<this.allMyGear.length; i++){
        for (var gear of this.allMyGear) {
            totalQuanatityOfGear += gear.quantity;
        }
        return totalQuanatityOfGear;
    }
    // FEATURE 11. Calculate the Sum of the Whole
    calculatePercentageOfGearValue() {
        var totalValueOfAllGear = this.calculateTotalValue();
        var allGearsWorthInPercentages;
        allGearsWorthInPercentages = [];
        for (var gear of this.allMyGear) {
            var onePercentOfWhole = totalValueOfAllGear / 100;
            var gearPercentValue = gear.value / onePercentOfWhole;
            allGearsWorthInPercentages.push([gear.title, gearPercentValue]);
        }
        return allGearsWorthInPercentages;
    }
    calculatePercentageOfGearInStorage() {
        var totalQuantityOfGear = this.calculateTotalQuantity();
        var gearsSpaceTakenInStorageData;
        gearsSpaceTakenInStorageData = [];
        for (var gear of this.allMyGear) {
            var onePercentOfWhole = totalQuantityOfGear / 100;
            var gearPercentValue = gear.quantity / onePercentOfWhole;
            gearsSpaceTakenInStorageData.push([gear.title, gearPercentValue]);
        }
        return gearsSpaceTakenInStorageData;
    }
    getCheckedOutQuantity() {
        let result;
        result = 0;
        for (var gear of this.allMyGear) {
            if (gear.checkedOut) {
                result += 1;
            }
        }
        if (result) {
            result = "no items have been checked out";
        }
        return result;
    }
}

//module.exports = Store;