var app = new Vue({
    el:'#app',
    data: {
        brand:"K's kickin designs",
        product: 'Socks',
        description: 'Striped winter warmer socks',
        image: '../view/icons/edit_black_24dp.svg',
        url: 'https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Fukmadcat.com%2Fwp-content%2Fuploads%2F2019%2F04%2Fsleepy-cat.jpg&f=1&nofb=1',
        inventory: 0,
        onSale: false,
        print_sizes: ["a1 poster", "a2 poster", "a3 poster", "a4 poster"],
        cart:5,
        inStock:true,

        background_colors: [
            {
                colorId:1,
                bgColor:"white"
            },
            {
                colorId:2,
                bgColor:"black"
            }
        ]
    },
    methods:{
        removeFromCart:function(){
            this.cart -=1
        },
        addToCart:function(){
            this.cart +=1
        }
    },
    computed:{
        onSaleTitle(){
            return this.brand+" "+this.product
        }
    }
})