//Store and Gear Inventory Manager <<<< Model >>>>
"use strict";
var gearTypeOptions;
(function (gearTypeOptions) {
    gearTypeOptions["Measurement"] = "Measurement tool";
    gearTypeOptions["Painting"] = "Painting";
    gearTypeOptions["Cutting_Tools"] = "Saws, Blades and Cutting Tools";
    gearTypeOptions["Hammering_Tools"] = "Hammering Tools";
    gearTypeOptions["Concreting"] = "Concreting";
    gearTypeOptions["Glues"] = "Glues, Adhesive";
    gearTypeOptions["Piping"] = "Piping and Plumbing";
    gearTypeOptions["Walling"] = "Walling";
    gearTypeOptions["Roofing"] = "Roofing";
    gearTypeOptions["Electrical"] = "Electrical Tools and Equipment";
    gearTypeOptions["Safety_Equipment"] = "Safety Equipment";
    gearTypeOptions["Automative_Tools"] = "Automative Tools";
    gearTypeOptions["Tightening_Tools"] = "Bolts and Wrenches";
    gearTypeOptions["Binding_Tools"] = "Screws, Nails, Joins";
    gearTypeOptions["Miscellaneous"] = "Miscellaneous";
    gearTypeOptions["Undefined"] = "undefined";
})(gearTypeOptions || (gearTypeOptions = {}));
/* globals localStorage */
// FEATURE 13. Provide default values
const STORAGE_KEY = 'storageManagerMobileAndWeb';
// FEATURE 2. Add a part
class Gear {
    constructor(newId, newTitle, newDesc, newQuantity, newType, newValue, newCondition) {
        this.id = newId;
        this.title = newTitle;
        this.desc = newDesc; //Feature 13. Use Title with a standard description
        this.quantity = newQuantity;
        this.gearType = newType;
        this.value = newValue;
        this.condition = newCondition;
        this.checkedOut = false; // FEATURE 13. Provide default values
    }
}
// FEATURE 1. Create a whole that acts as a Facade for parts
class Store {
    constructor() {
        this.allMyGear = [];
        // the following 3 attibutes are used to support editing a task
        this.editedGear = null;
        this.editedGearIndex = 0;
        this.beforeEditTitle = '';
        this.beforeEditDesc = '';
        this.beforeEditQuantity = 0;
        this.beforeEditType = gearTypeOptions.Undefined;
        this.beforeEditValue = 0.00;
        this.beforeEditCondition = '';
        this.beforeEditCheckedOut = false;
    }

    //Value > a 
    //Value <b
    // FEATURE 4. Filter parts
    filterGearValue(a, b) {
        var AllResults = this.allMyGear.filter(gear => gear.value > a && gear.value < b);
        var titlesOfMatchingGear = [];
        //for (var i=0; i<AllResults.length; i++){
        for (var gear of AllResults) {
            titlesOfMatchingGear.push(gear.title);
        }
        return titlesOfMatchingGear;
    }
    // FEATURE 4. Filter parts
    filterGearQuantity(a, b) {
        var AllResults = this.allMyGear.filter(gear => gear.quantity > a && gear.quantity < b);
        var titlesOfMatchingGear = [];
        //for (var i=0; i<AllResults.length; i++){
        for (var gear of AllResults) {
            titlesOfMatchingGear.push(gear.title);
        }
        return titlesOfMatchingGear;
    }
    // FEATURE 7. Load all parts from LocalStorage
    load() {
        // FEATURE 13. Provide default values
        return JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    }
    //  FEATURE 6. Save all parts to LocalStorage
    save() {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(this.allMyGear));
    }
    // FEATURE 2. Add a part
    addGear(newTitle, newQuantity, newType, newValue, newCondition) {
        newTitle = newTitle.trim();
        newQuantity = newQuantity;
        newType = newType.trim()
        newValue = newValue;
        newCondition = newCondition.trim();
        //Feature 10. Validate Inputs
        if (!newTitle /*||!newQuantity || !newType || !newValue ||!newCondition*/) {
            return;
        }
        else if (!newQuantity || isNaN(newQuantity) == true || typeof (newQuantity) === 'string') {
            return;
        }
        else if (!newType || newType=="") {
            return;
        }
        else if (!newValue || isNaN(newValue) == true || typeof (newValue) === 'string') {
            return;
        }
        else if (!newCondition) {
            return;
        }
        // FEATURE 13. Provide default values
        const newId = this.allMyGear.length + 1;
        const newDesc = "A " + newTitle + " avaliable for check out from storage";
        /*if(newDesc ==""){
          const newDesc = "A "+newTitle+" avaliable for checkOut from storage"
          }else{
            newDesc = newDesc.trim()
          }*/
        /*if(newCondition ==""){
        const newCondition = "New"
        }*/
        const newGear = new Gear(newId, newTitle, newDesc, newQuantity, newType, newValue, newCondition);
        this.allMyGear.push(newGear);
    }

    // FEATURE 15. Get all parts
    getAllGear() {
        return this.allMyGear;
    }
    // FEATURE 12. A calculation across many parts ! a weak example !
    // FEATURE 4. Filter parts
    //ReturnType
    getStoredGear() {
        return this.allMyGear.filter(gear => !gear.checkedOut);
    }
    // FEATURE 12. A calculation across many parts ! a weak example !
    // FEATURE 4. Filter parts
    getCheckedOutGear() {
        return this.allMyGear.filter(function (gear) {
            return gear.checkedOut;
        });
    }

    getCheckedOutGearCount() {
        return this.getCheckedOutGear().length;
    }

    // FEATURE 12. A calculation across many parts
    //previously stillToBeReturne
    getStoredGearCount() {
        return this.getStoredGear().length;
    }
    // FEATURE 12. A calculation across many parts
    //previously getAllStored()
    isAllGearReturned() {
        return this.getStoredGearCount() === this.allMyGear.length;
    }
    setAllGearStored() {
        this.allMyGear.forEach(function (gear) {
            gear.checkedOut = false;
        });
    }
    // FEATURE 5. Delete a selected part
    removeGear(targetGearTitle) {
        const index = this.allMyGear.findIndex(gear => gear.title === targetGearTitle);
        this.allMyGear.splice(index, 1);
    }
    // FEATURE 8. Update/edit a part
    // copies the task and title 
    startEditingGear(gear) {
        this.beforeEditTitle = gear.title;
        this.beforeEditDesc = gear.desc;
        this.beforeEditQuantity = gear.quantity;
        this.beforeEditType = gear.gearType;
        this.beforeEditValue = gear.value;
        this.beforeEditCondition = gear.condition;
        this.beforeEditCheckedOut = gear.checkedOut;
        this.editedGear = gear;
    }
    // FEATURE 8. Update/edit a part
    doneEditing(gear) {
        // FEATURE 10. Validate inputs
        if (!gear) {
            return;
        }
        this.editedGear = null;
        gear.title = gear.title.trim();
        if (gear.title == '' || !gear.title) {
            //this.removeGear(gear)
            gear.title = this.beforeEditTitle;
        }
        gear.desc = gear.desc.trim();
        if (gear.desc == '' || !gear.desc) {
            //this.removeGear(gear)
            gear.desc = this.beforeEditDesc;
        }
        if (!gear.quantity || isNaN(gear.quantity) == true || typeof(gear.quantity) === 'string' /*|| gear.quantity*/) {
            //this.removeGear(gear)
            gear.quantity = this.beforeEditQuantity;
        }
        // gear.gearType = gear.gearType.trim()
        if (gear.gearType==''||gear.gearType==undefined) {
          //this.removeGear(gear)
          gear.gearType = this.beforeEditType
        }
        if (!gear.value || isNaN(gear.value) == true || typeof (gear.value) === 'string' /*|| gear.value*/) {
            //this.removeGear(gear)
            gear.value = this.beforeEditValue;
        }
        gear.condition = gear.condition.trim();
        if (gear.condition == '' || !gear.condition) {
            //this.removeGear(gear)
            gear.condition = this.beforeEditCondition;
        }
        if (/*gear.checkedOut ||*/ !gear.checkedOut || typeof gear.checkedOut !== 'boolean') {
            //this.removeGear(gear)
            gear.checkedOut = this.beforeEditCheckedOut;
        }
    }
    // FEATURE 9. Discard /revert edits to a part
    cancelEditingGear(gear) {
        this.editedGear = null;
        gear.title = this.beforeEditTitle;
        gear.desc = this.beforeEditDesc;
        gear.quantity = this.beforeEditQuantity;
        gear.gearType = this.beforeEditType;
        gear.value = this.beforeEditValue;
        gear.condition = this.beforeEditCondition;
        gear.checkedOut = this.beforeEditCheckedOut;
    }
    // FEATURE 5. Delete a selected part
    removeGearCheckedOut() {
        this.allMyGear = this.getStoredGear();
    }
    // FEATURE 3. Sort parts
    sortGear(field) {
        if (field === 'Title') {
            this.allMyGear.sort(function (a, b) {
                if (a.title < b.title) {
                    return -1;
                }
                if (a.title > b.title) {
                    return 1;
                }
                // a must be equal to b
                return 0;
            });
        }
        if (field === 'Quantity') {
            this.allMyGear.sort(function (a, b) {
                if (a.quantity < b.quantity) {
                    return -1;
                }
                if (a.quantity > b.quantity) {
                    return 1;
                }
                // a must be equal to b
                return 0;
            });
        }
        if (field === 'Type') {
            this.allMyGear.sort(function (a, b) {
                if (a.gearType < b.gearType) {
                    return -1;
                }
                if (a.gearType > b.gearType) {
                    return 1;
                }
                // a must be equal to b
                return 0;
            });
        }
        if (field === 'Value') {
            this.allMyGear.sort(function (a, b) {
                if (a.value < b.value) {
                    return -1;
                }
                if (a.value > b.value) {
                    return 1;
                }
                // a must be equal to b
                return 0;
            });
        }
        if (field === 'Condition') {
            this.allMyGear.sort(function (a, b) {
                if (a.condition < b.condition) {
                    return -1;
                }
                if (a.condition > b.condition) {
                    return 1;
                }
                // a must be equal to b
                return 0;
            });
        }
    }
    // FEATURE 14. Find a part given a search criterion
    // NOTE: finds only FIRST match!
    findGear(targetTitle) {
        return this.allMyGear.find((gear) => gear.title === targetTitle);
    }
   
    calculateTotalValue() {
        var totalValueOfAllGear = 0;
        for (var gear of this.allMyGear) {
            totalValueOfAllGear += gear.value;
        }
        return totalValueOfAllGear;
    }
    calculateTotalQuantity() {
        var totalQuanatityOfGear = 0;
        //for(var i=0; i<this.allMyGear.length; i++){
        for (var gear of this.allMyGear) {
            totalQuanatityOfGear += gear.quantity;
        }
        return totalQuanatityOfGear;
    }
    // FEATURE 11. Calculate the Sum of the Whole
    calculatePercentageOfGearValue() {
        var totalValueOfAllGear = this.calculateTotalValue();
        var allGearsWorthInPercentages;
        allGearsWorthInPercentages = [];
        for (var gear of this.allMyGear) {
            var onePercentOfWhole = totalValueOfAllGear / 100;
            var gearPercentValue = gear.value / onePercentOfWhole;
            allGearsWorthInPercentages.push([gear.title, gearPercentValue]);
        }
        return allGearsWorthInPercentages;
    }
    calculatePercentageOfGearInStorage() {
        var totalQuantityOfGear = this.calculateTotalQuantity();
        var gearsSpaceTakenInStorageData;
        gearsSpaceTakenInStorageData = [];
        for (var gear of this.allMyGear) {
            var onePercentOfWhole = totalQuantityOfGear / 100;
            var gearPercentValue = gear.quantity / onePercentOfWhole;
            gearsSpaceTakenInStorageData.push([gear.title, gearPercentValue]);
        }
        return gearsSpaceTakenInStorageData;
    }
    getCheckedOutQuantity() {
        let result;
        result = 0;
        for (var gear of this.allMyGear) {
            if (gear.checkedOut) {
                result += 1;
            }
        }
        if (result) {
            result = "no items have been checked out";
        }
        return result;
    }
}


//Store and Gear Inventory Manager <<<< Local Storage Mock >>>>
class LocalStorageMock { 
    constructor() {
      this.store = {}
    }
   
    clear() {
      this.store = {}
    }
   
    getItem(key) {
      return this.store[key] || null
    }
   
    setItem(key, value) {
      this.store[key] = String(value)
    }
   
    removeItem(key) {
      delete this.store[key]
    }
  }
   
  global.localStorage = new LocalStorageMock 

//Store and Gear Inventory Manager <<<< Jest Testing >>>>
describe('storageManager', () => {
    var theStorage

    function getGear (allGear) {
      const allTitles = []
      for (const someGear of allGear) {
        allTitles.push(someGear.title)
      }
      return allTitles
    }

    beforeEach(() => {
        theStorage = new Store()
    });

    describe('adding gear', ()=> {
        describe('when a new piece of gear is added with a title of "hammer" is added',  ()=> {
            var theGear
            beforeEach(() => {
                theStorage.addGear('hammer', 1, "Building Tool", 50.00, "New")
                theGear = theStorage.allMyGear[0]
            });

            describe('adding a single item of gear', ()=>{
                test('should have an id of 1', ()=>{
                    expect(theGear.id).toBe(1)
                });
                test('should have a title of "hammer"', ()=> {
                    expect(theGear.title).toBe('hammer')
                  })
          
                  test('should have a description of "A hammer avaliable for checkOut from storage"', ()=> {
                    expect(theGear.desc).toBe('A hammer avaliable for check out from storage')
                  })
          
                  test('hammer should have a quantity of 1', ()=> {
                    expect(theGear.quantity).toBe(1)
                  })
          
                  test('hammer should have a type of "Building Tool"', ()=> {
                    expect(theGear.gearType).toBe('Building Tool')
                  })
          
                  test('hammer should have a value of "50.00" dollars', ()=> {
                    expect(theGear.value).toBe(50.00)
                  })
          
                  test('hammer should have a condition of "New"', ()=> {
                    expect(theGear.condition).toBe("New")
                  })
          
                  test('should not be checkedOut', ()=> {
                    expect(theGear.checkedOut).toBeFalsy();
                  })
            });

            describe('the storage app', ()=> {
                test('should have one piece of gear', ()=> {
                  expect(theStorage.allMyGear.length).toBe(1)
                })
        
                test('should have 0 pieces of gear checkedout', ()=> {
                  expect(theStorage.getCheckedOutGearCount()).toBe(0)
                  
                })
        
                test('gear should be reporting AllGearReturned as true', ()=> {
                  expect(theStorage.isAllGearReturned()).toBeTruthy();
                })
            });
        });
            

            describe('when three pieces of gear are added', ()=> {
                test('should have 3 pieces of gear', ()=> {
                  theStorage.addGear('7mm Nails', 250, "Building Equipment", 4.50, "New")
                  theStorage.addGear('Drill', 2, "Building Tool", 300.00, "Old")
                  theStorage.addGear('Screws 5mm', 30, "Building Equipment", 4.00, "New")
                  expect(theStorage.allMyGear.length).toBe(3)
                })
            });

        });

  
// FEATURE 6. Save all parts to LocalStorage
describe('save', ()=>  {
    test('should save some gear in localStorage when it has a single item', ()=>  {
      localStorage.clear()
      theStorage = new Store()
      theStorage.addGear('10mm x 1m oak wood', 40, "Building Equipment", 40.00, "New")
      theStorage.save()
      var gearJSON = localStorage.getItem(STORAGE_KEY)
      expect(gearJSON).toBeDefined();
    })
  
    test('should have the correct JSON for the correct piece of gear in localStorage', ()=>  {
      localStorage.clear()
      theStorage = new Store()
      theStorage.addGear('blue tile', 40, "Building Equipment", 120.00, "New")
      theStorage.save()
      var gearJSON = localStorage.getItem(STORAGE_KEY)
      //expect(itemJSON).toBe('[{"id":1,"title":"blue tile","desc":"A blue tile avaliable for check out from storage","quantity":40;"type":"Building Equipment"; "value":120;"condition":"New";"checkedOut":false}]')
      expect(gearJSON).toBe('[{"id":1,"title":"blue tile","desc":"A blue tile avaliable for check out from storage","quantity":40,"gearType":"Building Equipment","value":120,"condition":"New","checkedOut":false}]')
    
    })
  });

// FEATURE 7. Load all parts from LocalStorage
describe('load',  ()=> {
    test('should load some gear from localStorage when it has a piece of gear',  ()=> {
      // save something
      localStorage.clear()
      theStorage = new Store()
      theStorage.addGear('blue tile', 40, "Building Equipment", 120.00, "New")
      theStorage.save()
      // the start the model again
      theStorage = new Store()
      // and load
      theStorage.load()
      var gearJSON = localStorage.getItem(STORAGE_KEY)
      expect(gearJSON).toBeDefined();
    })
  
    test('should have the correct JSON for the loaded gear',  ()=> {
      // save something
      localStorage.clear()
      theStorage = new Store()
      theStorage.addGear('blue tile', 40, "Building Equipment", 120.00, "New")
      theStorage.save()
      // the start the model again
      theStorage = new Store()
      // and load
      theStorage.load()
      var itemJSON = localStorage.getItem(STORAGE_KEY)
      expect(itemJSON).toBe('[{"id":1,"title":"blue tile","desc":"A blue tile avaliable for check out from storage","quantity":40,"gearType":"Building Equipment","value":120,"condition":"New","checkedOut":false}]')
    })
  });

  // FEATURE 3. Sort parts
describe('sorting gear', ()=> {
    var theStorage
    beforeEach( ()=>{
      theStorage = new Store()
      theStorage.addGear('glue', 2, "Adhesive", 30.00, "Old")
      theStorage.addGear('drill', 1, "Building Tool", 150.00, "New")
      theStorage.addGear('nails', 150, "Building Equipment", 20.00, "Old")
      theStorage.addGear('wood', 30, "Building Material", 90.00, "Missing")
    })
    test('should put gear into alphabetic title order', ()=> {
      theStorage.sortGear('Title')
      const actualOrderedGearTitles = getGear(theStorage.allMyGear)
      const expectedSortedGearTitles = ['drill', 'glue', 'nails', 'wood']
      expect(expectedSortedGearTitles).toStrictEqual(actualOrderedGearTitles)
    })
  
    test('should put gear into ascending quantity order', ()=> {
      theStorage.sortGear('Quantity')
      const actualOrderedGearTitles = getGear(theStorage.allMyGear)
      const expectedSortedGearTitles = [ 'drill', 'glue', 'wood', 'nails' ]
      expect(expectedSortedGearTitles).toStrictEqual(actualOrderedGearTitles)
    })
  
    test('should put gear into alphabetical type order', ()=> {
      theStorage.sortGear('Type')
      const actualOrderedGearTitles = getGear(theStorage.allMyGear)
      const expectedSortedGearTitles = ['glue', 'nails', 'wood', 'drill']
      expect(expectedSortedGearTitles).toStrictEqual(actualOrderedGearTitles)
    })
  
    test('should put gear into low-high value', ()=> {
      theStorage.sortGear('Value')
      const actualOrderedGearTitles = getGear(theStorage.allMyGear)
      const expectedSortedGearTitles = [ 'nails', 'glue', 'wood', 'drill']
      expect(expectedSortedGearTitles).toStrictEqual(actualOrderedGearTitles)
    })
  
    test('should put gear into alphabetical condition order', ()=> {
      theStorage.sortGear('Condition')
      const actualOrderedGearTitles = getGear(theStorage.allMyGear)
      const expectedSortedGearTitles = ['wood', 'drill', 'glue', 'nails']
      expect(expectedSortedGearTitles).toStrictEqual(actualOrderedGearTitles)
    })
  });

  // FEATURE 4. Filter parts
describe('filtering gear by checking gear avaliability for checked in and checked out', ()=> {
    var theStorage
    beforeEach( ()=>{
    theStorage = new Store()
    theStorage.addGear('hammer', 1, "Building Tool", 20.00, "Old")
    theStorage.addGear('drill', 1, "Building Tool", 150.00, "New")
    theStorage.addGear('saw', 1, "Building Tool", 15.00, "Old")
    theStorage.allMyGear[1].checkedOut = true
    })
  
    test('should be able to return only stored Gear', ()=> {
      const expectedStorageCount = 2
      const expectedStoredGear = ['hammer', 'saw']
      const actualStoredGear = theStorage.getStoredGear()
      const actualStoredGearCount = actualStoredGear.length
      const actualStoredGearTitles = getGear(actualStoredGear)
      expect(actualStoredGearCount).toBe(expectedStorageCount)
      expect(actualStoredGearTitles).toStrictEqual(expectedStoredGear)
    })
  
    test('should be able to return only checkedOut gear', ()=> {
      const expectedCheckedOutGearCount= 1
      const expectedCheckedOutGearTitles = ['drill']
      const actualCheckedOutList = theStorage.getCheckedOutGear()
      const actualCheckedOutCount = actualCheckedOutList.length
      const actualCheckedOutGearTitles = getGear(actualCheckedOutList)
      expect(actualCheckedOutCount).toBe(expectedCheckedOutGearCount)
      expect(actualCheckedOutGearTitles).toStrictEqual(expectedCheckedOutGearTitles)
    })
  
    test('should correctly calculate the number of gear checked out of storage', ()=> {
      const expectedNumberOfGearCheckedOut = 1
      const actualNumberOfGearCheckedOut = theStorage.getCheckedOutGearCount()
      expect(actualNumberOfGearCheckedOut).toBe(expectedNumberOfGearCheckedOut)
    })
  })
  //Feature 4: Filter parts for Gear Value and Quantity
  describe('filtering gear for value and quantity', ()=> {
    var theStorage
    beforeEach( ()=> {
    theStorage = new Store()
    theStorage.addGear('glue', 2, "Adhesive", 30.00, "Old")
    theStorage.addGear('drill', 1, "Building Tool", 150.00, "New")
    theStorage.addGear('nails', 150, "Building Equipment", 20.00, "Old")
    theStorage.addGear('wood', 30, "Building Material", 90.00, "Missing")
    })
  
    test('should return the correct number of gear between $25-100 dollars', ()=> {
      const expectedGearValueFilterMatches = ['glue', 'wood']
      const actualMatchingGearInValueRange = theStorage.filterGearValue(25.00,100.00)
      expect(actualMatchingGearInValueRange).toStrictEqual(expectedGearValueFilterMatches)
    })
  
    test('should return gear that have a quantity between 25-200', ()=> {
      const expectedGearQuantityFilterMatches= [ 'nails', 'wood' ]
      const actualGearQuantityFilterMatches = theStorage.filterGearQuantity(25,200)
      expect(actualGearQuantityFilterMatches).toStrictEqual(expectedGearQuantityFilterMatches)
    })
  })

// FEATURE 5. Delete a selected part
describe('deleting some gear', ()=> {
    var theStorage 
    theStorage = new Store()
    theStorage.addGear('hammer', 1, "Building Tool", 20.00, "Old")
    theStorage.addGear('drill', 1, "Building Tool", 150.00, "New")
    theStorage.addGear('saw', 1, "Building Tool", 15.00, "Old")
    theStorage.removeGear('drill')
    test('should remove gear from storage', ()=> {
      const expectedGearTitles = ['hammer', 'saw']
      const actualGearTitles = getGear(theStorage.allMyGear)
      expect(actualGearTitles).toStrictEqual(expectedGearTitles)
    })
  
    test('should reduce the gear count following deletion', ()=> {
      const expectedRemainingGearCount = 2
      const actualRemainingGearCount = theStorage.allMyGear.length
      expect(actualRemainingGearCount).toBe(expectedRemainingGearCount)
    })
  })
  
  describe('removing all checked out gear', ()=> {
    var theStorage = new Store()
    theStorage.addGear('hammer', 1, "Building Tool", 20.00, "Old")
    theStorage.addGear('drill', 1, "Building Tool", 150.00, "New")
    theStorage.addGear('saw', 1, "Building Tool", 15.00, "Old")
    theStorage.addGear('oak panels 3m x 30xm', 45, "Equipment", 80.00, "New")
    theStorage.allMyGear[1].checkedOut = true
    theStorage.allMyGear[2].checkedOut = true
    theStorage.removeGearCheckedOut()
    test('should remove all of the checked out gear', ()=> {
      const expectedGearTitles = ['hammer', 'oak panels 3m x 30xm']
      const actualGearTitles = getGear(theStorage.allMyGear)
      expect(actualGearTitles).toStrictEqual(expectedGearTitles)
    })
  
    test('should reduce the gear count', ()=> {
      const expectedRemainingGearCount = 2
      const actualRemainingGearCount = theStorage.allMyGear.length
      expect(actualRemainingGearCount).toBe(expectedRemainingGearCount)
    })
  })

  // FEATURE 8. Update/edit a part
describe('editing a gear', ()=> {
    var theStorage
    beforeEach( ()=>{
    theStorage = new Store()
    theStorage.addGear('drill', 1, "Building Tool", 150.00, "New")
    })
    
    test('should change the title of the gear', ()=> {
      theStorage.startEditingGear(theStorage.allMyGear[0])
      theStorage.allMyGear[0].title = 'Nelsons drill'
      theStorage.doneEditing(theStorage.allMyGear[0])
      expect(theStorage.allMyGear[0].title).toBe('Nelsons drill')
    })
  
    test('should not change the title of the gear if title is empty', ()=> {
      theStorage.startEditingGear(theStorage.allMyGear[0])
      theStorage.allMyGear[0].title = ''
      theStorage.doneEditing(theStorage.allMyGear[0])
      expect(theStorage.allMyGear[0].title).toBe('drill')
    })
  
    test('should change the description of the gear', ()=> {
      theStorage.startEditingGear(theStorage.allMyGear[0])
      theStorage.allMyGear[0].desc = 'A 2013 model Nelsons drill with 2 Batterys and 6 different drill heads'
      theStorage.doneEditing(theStorage.allMyGear[0])
      expect(theStorage.allMyGear[0].desc).toBe('A 2013 model Nelsons drill with 2 Batterys and 6 different drill heads')
    })
  
    test('should not change the description of the gear if it is empty', ()=> {
      theStorage.startEditingGear(theStorage.allMyGear[0])
      theStorage.allMyGear[0].desc = ''
      theStorage.doneEditing(theStorage.allMyGear[0])
      expect(theStorage.allMyGear[0].desc).toBe('A drill avaliable for check out from storage')
    })
  
  
    test('should change the quantity of the gear', ()=> {
      theStorage.startEditingGear(theStorage.allMyGear[0])
      theStorage.allMyGear[0].quantity = 3
      theStorage.doneEditing(theStorage.allMyGear[0])
      expect(theStorage.allMyGear[0].quantity).toBe(3)
    })
  
    test('should not change the quantity of the gear if it is blank', ()=> {
      theStorage.startEditingGear(theStorage.allMyGear[0])
      theStorage.allMyGear[0].quantity = ''
      theStorage.doneEditing(theStorage.allMyGear[0])
      expect(theStorage.allMyGear[0].quantity).toBe(1)
    })
  
    test('should not change the quantity of the gear if it is not a number input', ()=> {
      theStorage.startEditingGear(theStorage.allMyGear[0])
      theStorage.allMyGear[0].quantity = "drei"
      theStorage.doneEditing(theStorage.allMyGear[0])
      expect(theStorage.allMyGear[0].quantity).toBe(1)
    })
  
    test('should change the type of the gear', ()=> {
      theStorage.startEditingGear(theStorage.allMyGear[0])
      theStorage.allMyGear[0].type = "electrical tools"
      theStorage.doneEditing(theStorage.allMyGear[0])
      expect(theStorage.allMyGear[0].type).toBe("electrical tools")
    })
  
    test('should not change the type of gear if it is blank', ()=> {
      theStorage.startEditingGear(theStorage.allMyGear[0])
      theStorage.allMyGear[0].gearType = ""
      theStorage.doneEditing(theStorage.allMyGear[0])
      expect(theStorage.allMyGear[0].gearType).toBe("Building Tool")
    })
  
    test('should change the value of the gear', ()=> {
      theStorage.startEditingGear(theStorage.allMyGear[0])
      theStorage.allMyGear[0].value = 250.50
      theStorage.doneEditing(theStorage.allMyGear[0])
      expect(theStorage.allMyGear[0].value).toBe(250.50)
    })
  
    test('should not change the value of the gear if it is not a number input', ()=> {
      theStorage.startEditingGear(theStorage.allMyGear[0])
      theStorage.allMyGear[0].value = "Three hundred dollars"
      theStorage.doneEditing(theStorage.allMyGear[0])
      expect(theStorage.allMyGear[0].value).toBe(150)
    })
  
    test('should not change the value of the gear if it is blank', ()=> {
      theStorage.startEditingGear(theStorage.allMyGear[0])
      theStorage.allMyGear[0].value = ""
      theStorage.doneEditing(theStorage.allMyGear[0])
      expect(theStorage.allMyGear[0].value).toBe(150)
    })
  
    test('should change the condition of the gear', ()=> {
      theStorage.startEditingGear(theStorage.allMyGear[0])
      theStorage.allMyGear[0].condition = "Missing"
      theStorage.doneEditing(theStorage.allMyGear[0])
      expect(theStorage.allMyGear[0].condition).toBe("Missing")
    })
  
    test('should not change the condition status of the gear if it is blank', ()=> {
      theStorage.startEditingGear(theStorage.allMyGear[0])
      theStorage.allMyGear[0].condition = ""
      theStorage.doneEditing(theStorage.allMyGear[0])
      expect(theStorage.allMyGear[0].condition).toBe("New")
    })
  
    test('should change the check out status of the gear', ()=> {
      theStorage.startEditingGear(theStorage.allMyGear[0])
      theStorage.allMyGear[0].checkedOut = true
      theStorage.doneEditing(theStorage.allMyGear[0])
      expect(theStorage.allMyGear[0].checkedOut).toBe(true)
    })
  
    test('should not change the check out status of the gear if it is not a boolean', ()=> {
      theStorage.startEditingGear(theStorage.allMyGear[0])
      theStorage.allMyGear[0].checkedOut = "true"
      theStorage.doneEditing(theStorage.allMyGear[0])
      expect(theStorage.allMyGear[0].checkedOut).toBe(false)
    })
  })

  // FEATURE 9. Discard /revert edits to a part
describe('discarding edits to gear', ()=> {
    var theStorage
    beforeEach( ()=> {
      theStorage = new Store()
      theStorage.addGear('drill', 1, "Building Tool", 150.00, "New")
    })
    test('should not change the title of the gear', ()=> {
      theStorage.startEditingGear(theStorage.allMyGear[0])
      theStorage.allMyGear[0].title = 'Bobbies drill'
      theStorage.cancelEditingGear(theStorage.allMyGear[0])
      expect(theStorage.allMyGear[0].title).toBe('drill')
    })
  
    test('should not change the description of the gear', ()=> {
      theStorage.startEditingGear(theStorage.allMyGear[0])
      theStorage.allMyGear[0].desc = 'A yellow and gray drill owned by bobby'
      theStorage.cancelEditingGear(theStorage.allMyGear[0])
      expect(theStorage.allMyGear[0].desc).toBe('A drill avaliable for check out from storage')
    })
  
    test('should not change the quantity of the gear', ()=> {
      theStorage.startEditingGear(theStorage.allMyGear[0])
      theStorage.allMyGear[0].quantity = 3
      theStorage.cancelEditingGear(theStorage.allMyGear[0])
      expect(theStorage.allMyGear[0].quantity).toBe(1)
    })
  
    test('should not change the type of the gear', ()=> {
      theStorage.startEditingGear(theStorage.allMyGear[0])
      theStorage.allMyGear[0].gearType = "Electrical Tools"
      theStorage.cancelEditingGear(theStorage.allMyGear[0])
      expect(theStorage.allMyGear[0].gearType).toBe("Building Tool")
    })
  
    test('should not change the value of the gear', ()=> {
      theStorage.startEditingGear(theStorage.allMyGear[0])
      theStorage.allMyGear[0].value = 100.00
      theStorage.cancelEditingGear(theStorage.allMyGear[0])
      expect(theStorage.allMyGear[0].value).toBe(150.00)
    })
  
    test('should not change the condition of the gear', ()=> {
      theStorage.startEditingGear(theStorage.allMyGear[0])
      theStorage.allMyGear[0].condition = "Faulty"
      theStorage.cancelEditingGear(theStorage.allMyGear[0])
      expect(theStorage.allMyGear[0].condition).toBe("New")
    })
  
    test('should not change the checkedOut status of the gear', ()=> {
      theStorage.startEditingGear(theStorage.allMyGear[0])
      theStorage.allMyGear[0].checkedOut = true
      theStorage.cancelEditingGear(theStorage.allMyGear[0])
      expect(theStorage.allMyGear[0].checkedOut).toBe(false)
    })
  })

  // FEATURE 10. Validate inputs
describe('validating inputs to a gear', ()=> {
    test('should not allow empty gear inputs titles, quantity, gearType, value, condition', ()=> {
      var theStorage = new Store()
      //title check
      theStorage.addGear('a',1, 'Building tool', 20.00, 'New')
      theStorage.addGear('',1, 'Building tool', 20.00, 'New')
      theStorage.addGear('  ',1, 'Building tool', 20.00, 'New')
      //Quantity check
      theStorage.addGear('b','', 'Building tool', 20.00, 'New')
      theStorage.addGear('c',' ', 'Building tool', 20.00, 'New')
      theStorage.addGear('d','s', 'Building tool', 20.00, 'New')
      theStorage.addGear('e',4, 'Building tool', 20.00, 'New')
      //Building Type Check
      theStorage.addGear('f',1, '', 20.00, 'New')
      theStorage.addGear('g',1, ' ', 20.00, 'New')
      //Value check
      theStorage.addGear('h',1, 'Building tool', "", 'New')
      theStorage.addGear('i',1, 'Building tool', " ", 'New')
      theStorage.addGear('j',1, 'Building tool', 20.4, 'New')
      //Condition Check
      theStorage.addGear('k',1, 'Material', 20.00, '')
      theStorage.addGear('l',1, 'Material', 20.00, ' ')
      theStorage.addGear('m',1, 'Material', 20.00, 'Old')
      const expectedGearTitles = ['a', 'e', 'j', 'm']
      const actualGearTitles = getGear(theStorage.allMyGear)
      expect(actualGearTitles).toStrictEqual(expectedGearTitles)
    })
  })

  // FEATURE 12. A calculation across many parts
describe('working out if all gear is returned', ()=> {
    test('should return true if all checkedOut gear is false', ()=> {
      var theStorage = new Store()
      expect(theStorage.isAllGearReturned()).toBeTruthy();
    })
  
    test('With gear added to storage it should be true that all gear is returned and nothing is checked out', ()=> {
      var theStorage = new Store()
      theStorage.addGear('ceramic tiles',30, 'Material', 100.00, 'Old')
      theStorage.addGear('glue',3, 'Binding agent', 60.00, 'New')
      expect(theStorage.isAllGearReturned()).toBeTruthy();
    })
  
    test('should return false for allGearReturned when gear has been checked out of storage ', ()=> {
      var theStorage = new Store()
      theStorage.addGear('ceramic tiles',30, 'Material', 100.00, 'Old')
      theStorage.addGear('glue',3, 'Binding agent', 60.00, 'New')
      theStorage.allMyGear[0].checkedOut = true
      theStorage.allMyGear[1].checkedOut = true
      expect(theStorage.isAllGearReturned()).toBeFalsy();
    })
  })
  
  describe('counting stored gear', ()=> {
    test('should return the correct number of gear in storage as new gear is added and checked out', ()=> {
      var theStorage = new Store()
      expect(theStorage.getCheckedOutGearCount()).toBe(0)
      theStorage.addGear('ceramic tiles',30, 'Material', 100.00, 'Old')
      expect(theStorage.getCheckedOutGearCount()).toBe(0)
      theStorage.addGear('glue',3, 'Binding agent', 60.00, 'New')
      theStorage.allMyGear[0].checkedOut = true
      expect(theStorage.getCheckedOutGearCount()).toBe(1)
      theStorage.allMyGear[1].checkedOut = true
      expect(theStorage.getCheckedOutGearCount()).toBe(2)
      theStorage.allMyGear[0].checkedOut = false
      theStorage.allMyGear[1].checkedOut = false
      expect(theStorage.getCheckedOutGearCount()).toBe(0)
    })
  })
  
   // FEATURE 12. A calculation across many parts for stats of attributes
   describe('working out stats of gear', ()=> {
    beforeEach( ()=> {
      theStorage = new Store()
      theStorage.addGear('glue', 2, "Adhesive", 30.00, "Old")
      theStorage.addGear('drill', 1, "Building Tool", 150.00, "New")
      theStorage.addGear('nails', 150, "Building Equipment", 20.00, "Old")
      theStorage.addGear('wood', 30, "Building Material", 90.00, "Missing")
      theStorage.addGear('Tiles', 100, "Building Material", 180.00, "Old")
      theStorage.addGear('chainsaw', 1, "Building Tool", 120.00, "New")
      theStorage.addGear('clamps', 5, "Building Tool", 50.00, "New")
    })
    test('should output the total value of all gear owned as 640', ()=> {
      const actualTotalValue = theStorage.calculateTotalValue()
      const expectedTotalValue = 640
      expect(expectedTotalValue).toStrictEqual(actualTotalValue)
    })
    test('should output the total quantity of all gear owned as 289', ()=> {
      const actualTotalQuantity = theStorage.calculateTotalQuantity()
      const expectedTotalQuantity = 289
      expect(expectedTotalQuantity).toStrictEqual(actualTotalQuantity)
    })
  })

  // FEATURE 11. A calculation within a part
describe('Should be able to output correct percentages for quantity and value of gear in relation to total quantity and value in storage', ()=> {
    beforeEach( ()=> {
      theStorage = new Store()
      theStorage.addGear('glue', 2, "Adhesive", 30.00, "Old")
      theStorage.addGear('drill', 1, "Building Tool", 150.00, "New")
      theStorage.addGear('nails', 150, "Building Equipment", 20.00, "Old")
      theStorage.addGear('wood', 30, "Building Material", 90.00, "Missing")
      theStorage.addGear('Tiles', 100, "Building Material", 180.00, "Old")
    })
    test('Outputs the correct percentage for first and last piece of gears total value out of the total value in storage', ()=> {
      const actualPercentValuesForGear = theStorage.calculatePercentageOfGearValue()
      const actualGearOneData = actualPercentValuesForGear[0]
      const expectedDataValuesForGearOne = [ 'glue', 6.382978723404255 ]
      const actualLastPieceOfGearData = actualPercentValuesForGear[actualPercentValuesForGear.length-1]
      const expectedDataValuesForLastPieceOfGear = [  'Tiles', 38.29787234042553  ]
      expect(expectedDataValuesForGearOne).toStrictEqual(actualGearOneData)
      expect(expectedDataValuesForLastPieceOfGear).toStrictEqual(actualLastPieceOfGearData )
    })
    test('should output the correct percent for quantity of each piece of gear in relation to total quantity of gear in storage', ()=> {
      const actualPercentDataForQuantityOfGear = theStorage.calculatePercentageOfGearInStorage()
      const actualGearOneData = actualPercentDataForQuantityOfGear[0]
      const expectedDataForQuantityOfGearOne = [ 'glue', 0.7067137809187279 ]
      const actualLastPieceOfGearData = actualPercentDataForQuantityOfGear[actualPercentDataForQuantityOfGear.length-1]
      const expectedDataValuesForLastPieceOfGear = [  'Tiles', 35.3356890459364  ]
      expect(expectedDataForQuantityOfGearOne).toStrictEqual(actualGearOneData)
      expect(expectedDataValuesForLastPieceOfGear).toStrictEqual(actualLastPieceOfGearData)
    })
  })


  // FEATURE 13. Provide default values
describe('the default value for new gear', ()=> {
    test('should allocate a sequentially incrementing id to all new gear', ()=> {
      var theStorage = new Store()
      for (let expectedId = 1; expectedId < 5; expectedId += 1) {
        theStorage.addGear('Miscellanious Gear',1, 'Building Equipment', 5.00, 'New')
        var actualId = theStorage.allMyGear[theStorage.allMyGear.length - 1].id
        expect(actualId).toBe(expectedId)
      }
    })
  
    test('should make sure all new gear is not checked out', ()=> {
      var theStorage = new Store()
      theStorage.addGear('Miscellanious Gear',1, 'Building Equipment', 5.00, 'New')
      const actualCheckedOut = theStorage.allMyGear[0].checkedOut
      expect(actualCheckedOut).toBeFalsy();
    })
  
    test('when gear is added description should be automatically made and contain the title of gear', ()=> {
      var theStorage = new Store()
      theStorage.addGear('Saw',1, 'Building Equipment', 5.00, 'New')
      const actualDesc = theStorage.allMyGear[0].desc
      const expectedDesc = 'A Saw avaliable for check out from storage'
      expect(actualDesc).toBe(expectedDesc)
    })
  })

  // FEATURE 14. Find a part given a search criterion
describe('finding gear inside storage', ()=> {
    test('should find nothing with an empty gear list', ()=> {
      var theStorage = new Store()
      const actualFoundGear = theStorage.findGear('alan key')
      expect(actualFoundGear).toBeUndefined();
    })
  
    test('should find the only gear with a title when that title is unique', ()=> {
      var theStorage = new Store()
      theStorage.addGear('Alan key',1, 'Building Equipment', 10.00, 'New')
      theStorage.addGear('Bolt screws',16, 'Binding agent', 7.50, 'New')
      theStorage.addGear('Wood planks',15, 'Material', 5.00, 'New')
      const actualFoundGear = theStorage.findGear('Bolt screws')
      expect(actualFoundGear).toBeDefined();
      const expectedFoundTitle = 'Bolt screws'
      const actualFoundTitle = actualFoundGear.title
      expect(actualFoundTitle).toBe(expectedFoundTitle)
    })
  
    test('should find the first task with that title when there is more than one task with the same title', ()=> {
      var theStorage = new Store()
      theStorage.addGear('Alan key',1, 'Building Equipment', 10.00, 'New')
      theStorage.addGear('Bolt screws',16, 'Binding agent', 7.50, 'New')
      theStorage.addGear('Alan key',1, 'Building Equipment', 5.00, 'Old')
      theStorage.addGear('Wood planks',15, 'Material', 5.00, 'New')
      const actualFoundGear = theStorage.findGear('Alan key')
      expect(actualFoundGear).toBeDefined();
      const expectedFoundTitle = 'Alan key'
      const actualFoundTitle = actualFoundGear.title
      expect(actualFoundTitle).toBe(expectedFoundTitle)
      const expectedFoundId = 1
      const actualFoundId = actualFoundGear.id
      expect(actualFoundId).toBe(expectedFoundId)
    })
  })

  // FEATURE 15. Get all parts
 describe('Getting all gear from storage', ()=> {
    var theStorage
  beforeEach(function(){
    theStorage = new Store()
    theStorage.addGear('Alan key',1, 'Building Equipment', 10.00, 'New')
    theStorage.addGear('Bolt screws',16, 'Binding agent', 7.50, 'New')
    theStorage.addGear('Wood planks',15, 'Material', 5.00, 'New')
  })
  test('should exist and have the correct number of gear stored', ()=> {
    const allExistingGearInStorage = theStorage.getAllGear()
    expect(allExistingGearInStorage).toBeDefined()
    expect(allExistingGearInStorage.length).toBe(3)
  })

  test('getAllGear() should have the correct titles for all stored gear', ()=> {
    const allExistingGearInStorage = theStorage.getAllGear()
    expect(allExistingGearInStorage[0].title).toBe('Alan key')
    expect(allExistingGearInStorage[1].title).toBe('Bolt screws')
    expect(allExistingGearInStorage[2].title).toBe('Wood planks')
  })

  test('getAllGear() should have the correct quantity for all stored gear', ()=> {
    const allExistingGearInStorage = theStorage.getAllGear()
    expect(allExistingGearInStorage[0].quantity).toBe(1)
    expect(allExistingGearInStorage[1].quantity).toBe(16)
    expect(allExistingGearInStorage[2].quantity).toBe(15)
  })

  test('getAllGear() should have the correct type for all stored gear', ()=> {
    const allExistingGearInStorage = theStorage.getAllGear()
    expect(allExistingGearInStorage[0].gearType).toBe('Building Equipment')
    expect(allExistingGearInStorage[1].gearType).toBe('Binding agent')
    expect(allExistingGearInStorage[2].gearType).toBe('Material')
  })

  test('getAllGear() should have the correct value for each piece of gear stored', ()=> {
    const allExistingGearInStorage = theStorage.getAllGear()
    expect(allExistingGearInStorage[0].value).toBe(10.00)
    expect(allExistingGearInStorage[1].value).toBe(7.50)
    expect(allExistingGearInStorage[2].value).toBe(5.00)
  })

  test('getAllGear() should have the correct Description for each piece of gear stored', ()=> {
    const allExistingGearInStorage = theStorage.getAllGear()
    expect(allExistingGearInStorage[0].desc).toBe('A Alan key avaliable for check out from storage')
    expect(allExistingGearInStorage[1].desc).toBe('A Bolt screws avaliable for check out from storage')
    expect(allExistingGearInStorage[2].desc).toBe('A Wood planks avaliable for check out from storage')
  })

  test('getAllGear() should have the correct CheckedOut status of false for each piece of gear stored', ()=> {
    const allExistingGearInStorage = theStorage.getAllGear()
    expect(allExistingGearInStorage[0].checkedOut).toBe(false)
    expect(allExistingGearInStorage[1].checkedOut).toBe(false)
    expect(allExistingGearInStorage[2].checkedOut).toBe(false)
  })
})

//I am the last closing bracket with beforeEach included
});

// //to run ensure pointing at jest folder and then type npm run test OR npm test -- --coverage