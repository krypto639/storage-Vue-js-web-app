/* globals describe it xdescribe xit beforeEach expect TodoList localStorage STORAGE_KEY */
describe('storageManager', function () {
  var theStorage

  function getGear (allGear) {
    const allTitles = []
    for (const someGear of allGear) {
      allTitles.push(someGear.title)
    }
    return allTitles
  }

  beforeEach(function () {
    theStorage = new Store()
  })

  describe('adding gear', function () {
    // FEATURE 1. Create a whole that acts as a Facade for parts
    // FEATURE 2. Add a part
    describe('when a new piece of gear is added with a title of "hammer" is added', function () {
      var theGear
      beforeEach(function () {

        theStorage.addGear('hammer', 1, "Building Tool", 50.00, "New")
        theGear = theStorage.allMyGear[0]
      })

      describe('adding a single item of gear', function () {
        it('should have an id of 1', function () {
          expect(theGear.id).to.equal(1)
        })

        it('should have a title of "hammer"', function () {
          expect(theGear.title).to.equal('hammer')
        })

        it('should have a description of "A hammer avaliable for checkOut from storage"', function () {
          expect(theGear.desc).to.equal('A hammer avaliable for check out from storage')
        })

        it('hammer should have a quantity of 1', function () {
          expect(theGear.quantity).to.equal(1)
        })

        it('hammer should have a type of "Building Tool"', function () {
          expect(theGear.gearType).to.equal('Building Tool')
        })

        it('hammer should have a value of "50.00" dollars', function () {
          expect(theGear.value).to.equal(50.00)
        })

        it('hammer should have a condition of "New"', function () {
          expect(theGear.condition).to.equal("New")
        })

        it('should not be checkedOut', function () {
          expect(theGear.checkedOut).to.be.false
        })
      })

      describe('the storage app', function () {
        it('should have one piece of gear', function () {
          expect(theStorage.allMyGear.length).to.equal(1)
        })

        it('should have 0 pieces of gear checkedout', function () {
          expect(theStorage.getCheckedOutGearCount()).to.equal(0)
          
        })

        it('gear should be reporting AllGearReturned as true', function () {
          expect(theStorage.isAllGearReturned()).to.be.true
        })
      })
    })

    describe('when three pieces of gear are added', function () {
      it('should have 3 pieces of gear', function () {
        theStorage.addGear('7mm Nails', 250, "Building Equipment", 4.50, "New")
        theStorage.addGear('Drill', 2, "Building Tool", 300.00, "Old")
        theStorage.addGear('Screws 5mm', 30, "Building Equipment", 4.00, "New")
        expect(theStorage.allMyGear.length).to.equal(3)
      })
    })
  })

  // FEATURE 6. Save all parts to LocalStorage
describe('save', function () {
  it('should save some gear in localStorage when it has a single item', function () {
    localStorage.clear()
    theStorage = new Store()
    theStorage.addGear('10mm x 1m oak wood', 40, "Building Equipment", 40.00, "New")
    theStorage.save()
    var gearJSON = localStorage.getItem(STORAGE_KEY)
    expect(gearJSON).to.exist
  })

  it('should have the correct JSON for the correct piece of gear in localStorage', function () {
    localStorage.clear()
    theStorage = new Store()
    theStorage.addGear('blue tile', 40, "Building Equipment", 120.00, "New")
    theStorage.save()
    var gearJSON = localStorage.getItem(STORAGE_KEY)
    //expect(itemJSON).to.equal('[{"id":1,"title":"blue tile","desc":"A blue tile avaliable for check out from storage","quantity":40;"type":"Building Equipment"; "value":120;"condition":"New";"checkedOut":false}]')
    expect(gearJSON).to.equal('[{"id":1,"title":"blue tile","desc":"A blue tile avaliable for check out from storage","quantity":40,"gearType":"Building Equipment","value":120,"condition":"New","checkedOut":false}]')
  
  })
})

// FEATURE 7. Load all parts from LocalStorage
describe('load', function () {
  it('should load some gear from localStorage when it has a piece of gear', function () {
    // save something
    localStorage.clear()
    theStorage = new Store()
    theStorage.addGear('blue tile', 40, "Building Equipment", 120.00, "New")
    theStorage.save()
    // the start the model again
    theStorage = new Store()
    // and load
    theStorage.load()
    var gearJSON = localStorage.getItem(STORAGE_KEY)
    expect(gearJSON).to.exist
  })

  it('should have the correct JSON for the loaded gear', function () {
    // save something
    localStorage.clear()
    theStorage = new Store()
    theStorage.addGear('blue tile', 40, "Building Equipment", 120.00, "New")
    theStorage.save()
    // the start the model again
    theStorage = new Store()
    // and load
    theStorage.load()
    var itemJSON = localStorage.getItem(STORAGE_KEY)
    expect(itemJSON).to.equal('[{"id":1,"title":"blue tile","desc":"A blue tile avaliable for check out from storage","quantity":40,"gearType":"Building Equipment","value":120,"condition":"New","checkedOut":false}]')
  })
})

// FEATURE 3. Sort parts
describe('sorting gear', function () {
  var theStorage
  beforeEach(function () {
    theStorage = new Store()
    theStorage.addGear('glue', 2, "Adhesive", 30.00, "Old")
    theStorage.addGear('drill', 1, "Building Tool", 150.00, "New")
    theStorage.addGear('nails', 150, "Building Equipment", 20.00, "Old")
    theStorage.addGear('wood', 30, "Building Material", 90.00, "Missing")
  })
  it('should put gear into alphabetic title order', function () {
    theStorage.sortGear('Title')
    const actualOrderedGearTitles = getGear(theStorage.allMyGear)
    const expectedSortedGearTitles = ['drill', 'glue', 'nails', 'wood']
    expect(expectedSortedGearTitles).to.deep.equal(actualOrderedGearTitles)
  })

  it('should put gear into ascending quantity order', function () {
    theStorage.sortGear('Quantity')
    const actualOrderedGearTitles = getGear(theStorage.allMyGear)
    const expectedSortedGearTitles = [ 'drill', 'glue', 'wood', 'nails' ]
    expect(expectedSortedGearTitles).to.deep.equal(actualOrderedGearTitles)
  })

  it('should put gear into alphabetical type order', function () {
    theStorage.sortGear('Type')
    const actualOrderedGearTitles = getGear(theStorage.allMyGear)
    const expectedSortedGearTitles = ['glue', 'nails', 'wood', 'drill']
    expect(expectedSortedGearTitles).to.deep.equal(actualOrderedGearTitles)
  })

  it('should put gear into low-high value', function () {
    theStorage.sortGear('Value')
    const actualOrderedGearTitles = getGear(theStorage.allMyGear)
    const expectedSortedGearTitles = [ 'nails', 'glue', 'wood', 'drill']
    expect(expectedSortedGearTitles).to.deep.equal(actualOrderedGearTitles)
  })

  it('should put gear into alphabetical condition order', function () {
    theStorage.sortGear('Condition')
    const actualOrderedGearTitles = getGear(theStorage.allMyGear)
    const expectedSortedGearTitles = ['wood', 'drill', 'glue', 'nails']
    expect(expectedSortedGearTitles).to.deep.equal(actualOrderedGearTitles)
  })

})

// FEATURE 4. Filter parts
describe('filtering gear by checking gear avaliability for checked in and checked out', function () {
  var theStorage
  beforeEach(function () {
  theStorage = new Store()
  theStorage.addGear('hammer', 1, "Building Tool", 20.00, "Old")
  theStorage.addGear('drill', 1, "Building Tool", 150.00, "New")
  theStorage.addGear('saw', 1, "Building Tool", 15.00, "Old")
  theStorage.allMyGear[1].checkedOut = true
  })

  it('should be able to return only stored Gear', function () {
    const expectedStorageCount = 2
    const expectedStoredGear = ['hammer', 'saw']
    const actualStoredGear = theStorage.getStoredGear()
    const actualStoredGearCount = actualStoredGear.length
    const actualStoredGearTitles = getGear(actualStoredGear)
    expect(actualStoredGearCount).to.equal(expectedStorageCount)
    expect(actualStoredGearTitles).to.deep.equal(expectedStoredGear)
  })

  it('should be able to return only checkedOut gear', function () {
    const expectedCheckedOutGearCount= 1
    const expectedCheckedOutGearTitles = ['drill']
    const actualCheckedOutList = theStorage.getCheckedOutGear()
    const actualCheckedOutCount = actualCheckedOutList.length
    const actualCheckedOutGearTitles = getGear(actualCheckedOutList)
    expect(actualCheckedOutCount).to.equal(expectedCheckedOutGearCount)
    expect(actualCheckedOutGearTitles).to.deep.equal(expectedCheckedOutGearTitles)
  })

  it('should correctly calculate the number of gear checked out of storage', function () {
    const expectedNumberOfGearCheckedOut = 1
    const actualNumberOfGearCheckedOut = theStorage.getCheckedOutGearCount()
    expect(actualNumberOfGearCheckedOut).to.equal(expectedNumberOfGearCheckedOut)
  })
})
//Feature 4: Filter parts for Gear Value and Quantity
describe('filtering gear for value and quantity', function () {
  var theStorage
  beforeEach(function () {
  theStorage = new Store()
  theStorage.addGear('glue', 2, "Adhesive", 30.00, "Old")
  theStorage.addGear('drill', 1, "Building Tool", 150.00, "New")
  theStorage.addGear('nails', 150, "Building Equipment", 20.00, "Old")
  theStorage.addGear('wood', 30, "Building Material", 90.00, "Missing")
  })

  it('should return the correct number of gear between $25-100 dollars', function () {
    const expectedGearValueFilterMatches = ['glue', 'wood']
    const actualMatchingGearInValueRange = theStorage.filterGearValue(25.00,100.00)
    expect(actualMatchingGearInValueRange).to.deep.equal(expectedGearValueFilterMatches)
  })

  it('should return gear that have a quantity between 25-200', function () {
    const expectedGearQuantityFilterMatches= [ 'nails', 'wood' ]
    const actualGearQuantityFilterMatches = theStorage.filterGearQuantity(25,200)
    expect(actualGearQuantityFilterMatches).to.deep.equal(expectedGearQuantityFilterMatches)
  })
  
})

// FEATURE 5. Delete a selected part
describe('deleting some gear', function () {
  var theStorage 
  theStorage = new Store()
  theStorage.addGear('hammer', 1, "Building Tool", 20.00, "Old")
  theStorage.addGear('drill', 1, "Building Tool", 150.00, "New")
  theStorage.addGear('saw', 1, "Building Tool", 15.00, "Old")
  theStorage.removeGear('drill')
  it('should remove gear from storage', function () {
    const expectedGearTitles = ['hammer', 'saw']
    const actualGearTitles = getGear(theStorage.allMyGear)
    expect(actualGearTitles).to.deep.equal(expectedGearTitles)
  })

  it('should reduce the gear count following deletion', function () {
    const expectedRemainingGearCount = 2
    const actualRemainingGearCount = theStorage.allMyGear.length
    expect(actualRemainingGearCount).to.equal(expectedRemainingGearCount)
  })
})

describe('removing all checked out gear', function () {
  var theStorage = new Store()
  theStorage.addGear('hammer', 1, "Building Tool", 20.00, "Old")
  theStorage.addGear('drill', 1, "Building Tool", 150.00, "New")
  theStorage.addGear('saw', 1, "Building Tool", 15.00, "Old")
  theStorage.addGear('oak panels 3m x 30xm', 45, "Equipment", 80.00, "New")
  theStorage.allMyGear[1].checkedOut = true
  theStorage.allMyGear[2].checkedOut = true
  theStorage.removeGearCheckedOut()
  it('should remove all of the checked out gear', function () {
    const expectedGearTitles = ['hammer', 'oak panels 3m x 30xm']
    const actualGearTitles = getGear(theStorage.allMyGear)
    expect(actualGearTitles).to.deep.equal(expectedGearTitles)
  })

  it('should reduce the gear count', function () {
    const expectedRemainingGearCount = 2
    const actualRemainingGearCount = theStorage.allMyGear.length
    expect(actualRemainingGearCount).to.equal(expectedRemainingGearCount)
  })
})

// FEATURE 8. Update/edit a part
describe('editing a gear', function () {
  var theStorage
  beforeEach(function(){
  theStorage = new Store()
  theStorage.addGear('drill', 1, "Building Tool", 150.00, "New")
  })
  
  it('should change the title of the gear', function () {
    theStorage.startEditingGear(theStorage.allMyGear[0])
    theStorage.allMyGear[0].title = 'Nelsons drill'
    theStorage.doneEditing(theStorage.allMyGear[0])
    expect(theStorage.allMyGear[0].title).to.equal('Nelsons drill')
  })

  it('should not change the title of the gear if title is empty', function () {
    theStorage.startEditingGear(theStorage.allMyGear[0])
    theStorage.allMyGear[0].title = ''
    theStorage.doneEditing(theStorage.allMyGear[0])
    expect(theStorage.allMyGear[0].title).to.equal('drill')
  })

  it('should change the description of the gear', function () {
    theStorage.startEditingGear(theStorage.allMyGear[0])
    theStorage.allMyGear[0].desc = 'A 2013 model Nelsons drill with 2 Batterys and 6 different drill heads'
    theStorage.doneEditing(theStorage.allMyGear[0])
    expect(theStorage.allMyGear[0].desc).to.equal('A 2013 model Nelsons drill with 2 Batterys and 6 different drill heads')
  })

  it('should not change the description of the gear if it is empty', function () {
    theStorage.startEditingGear(theStorage.allMyGear[0])
    theStorage.allMyGear[0].desc = ''
    theStorage.doneEditing(theStorage.allMyGear[0])
    expect(theStorage.allMyGear[0].desc).to.equal('A drill avaliable for check out from storage')
  })


  it('should change the quantity of the gear', function () {
    theStorage.startEditingGear(theStorage.allMyGear[0])
    theStorage.allMyGear[0].quantity = 3
    theStorage.doneEditing(theStorage.allMyGear[0])
    expect(theStorage.allMyGear[0].quantity).to.equal(3)
  })

  it('should not change the quantity of the gear if it is blank', function () {
    theStorage.startEditingGear(theStorage.allMyGear[0])
    theStorage.allMyGear[0].quantity = ''
    theStorage.doneEditing(theStorage.allMyGear[0])
    expect(theStorage.allMyGear[0].quantity).to.equal(1)
  })

  it('should not change the quantity of the gear if it is not a number input', function () {
    theStorage.startEditingGear(theStorage.allMyGear[0])
    theStorage.allMyGear[0].quantity = "drei"
    theStorage.doneEditing(theStorage.allMyGear[0])
    expect(theStorage.allMyGear[0].quantity).to.equal(1)
  })

  it('should change the type of the gear', function () {
    theStorage.startEditingGear(theStorage.allMyGear[0])
    theStorage.allMyGear[0].type = "electrical tools"
    theStorage.doneEditing(theStorage.allMyGear[0])
    expect(theStorage.allMyGear[0].type).to.equal("electrical tools")
  })

  it('should not change the type of gear if it is blank', function () {
    theStorage.startEditingGear(theStorage.allMyGear[0])
    theStorage.allMyGear[0].gearType = ""
    theStorage.doneEditing(theStorage.allMyGear[0])
    expect(theStorage.allMyGear[0].gearType).to.equal("Building Tool")
  })

  it('should change the value of the gear', function () {
    theStorage.startEditingGear(theStorage.allMyGear[0])
    theStorage.allMyGear[0].value = 250.50
    theStorage.doneEditing(theStorage.allMyGear[0])
    expect(theStorage.allMyGear[0].value).to.equal(250.50)
  })

  it('should not change the value of the gear if it is not a number input', function () {
    theStorage.startEditingGear(theStorage.allMyGear[0])
    theStorage.allMyGear[0].value = "Three hundred dollars"
    theStorage.doneEditing(theStorage.allMyGear[0])
    expect(theStorage.allMyGear[0].value).to.equal(150)
  })

  it('should not change the value of the gear if it is blank', function () {
    theStorage.startEditingGear(theStorage.allMyGear[0])
    theStorage.allMyGear[0].value = ""
    theStorage.doneEditing(theStorage.allMyGear[0])
    expect(theStorage.allMyGear[0].value).to.equal(150)
  })

  it('should change the condition of the gear', function () {
    theStorage.startEditingGear(theStorage.allMyGear[0])
    theStorage.allMyGear[0].condition = "Missing"
    theStorage.doneEditing(theStorage.allMyGear[0])
    expect(theStorage.allMyGear[0].condition).to.equal("Missing")
  })

  it('should not change the condition status of the gear if it is blank', function () {
    theStorage.startEditingGear(theStorage.allMyGear[0])
    theStorage.allMyGear[0].condition = ""
    theStorage.doneEditing(theStorage.allMyGear[0])
    expect(theStorage.allMyGear[0].condition).to.equal("New")
  })

  it('should change the check out status of the gear', function () {
    theStorage.startEditingGear(theStorage.allMyGear[0])
    theStorage.allMyGear[0].checkedOut = true
    theStorage.doneEditing(theStorage.allMyGear[0])
    expect(theStorage.allMyGear[0].checkedOut).to.equal(true)
  })

  it('should not change the check out status of the gear if it is not a boolean', function () {
    theStorage.startEditingGear(theStorage.allMyGear[0])
    theStorage.allMyGear[0].checkedOut = "true"
    theStorage.doneEditing(theStorage.allMyGear[0])
    expect(theStorage.allMyGear[0].checkedOut).to.equal(false)
  })
})

// FEATURE 9. Discard /revert edits to a part
describe('discarding edits to gear', function () {
  var theStorage
  beforeEach(function(){
    theStorage = new Store()
    theStorage.addGear('drill', 1, "Building Tool", 150.00, "New")
  })
  it('should not change the title of the gear', function () {
    theStorage.startEditingGear(theStorage.allMyGear[0])
    theStorage.allMyGear[0].title = 'Bobbies drill'
    theStorage.cancelEditingGear(theStorage.allMyGear[0])
    expect(theStorage.allMyGear[0].title).to.equal('drill')
  })

  it('should not change the description of the gear', function () {
    theStorage.startEditingGear(theStorage.allMyGear[0])
    theStorage.allMyGear[0].desc = 'A yellow and gray drill owned by bobby'
    theStorage.cancelEditingGear(theStorage.allMyGear[0])
    expect(theStorage.allMyGear[0].desc).to.equal('A drill avaliable for check out from storage')
  })

  it('should not change the quantity of the gear', function () {
    theStorage.startEditingGear(theStorage.allMyGear[0])
    theStorage.allMyGear[0].quantity = 3
    theStorage.cancelEditingGear(theStorage.allMyGear[0])
    expect(theStorage.allMyGear[0].quantity).to.equal(1)
  })

  it('should not change the type of the gear', function () {
    theStorage.startEditingGear(theStorage.allMyGear[0])
    theStorage.allMyGear[0].gearType = "Electrical Tools"
    theStorage.cancelEditingGear(theStorage.allMyGear[0])
    expect(theStorage.allMyGear[0].gearType).to.equal("Building Tool")
  })

  it('should not change the value of the gear', function () {
    theStorage.startEditingGear(theStorage.allMyGear[0])
    theStorage.allMyGear[0].value = 100.00
    theStorage.cancelEditingGear(theStorage.allMyGear[0])
    expect(theStorage.allMyGear[0].value).to.equal(150.00)
  })

  it('should not change the condition of the gear', function () {
    theStorage.startEditingGear(theStorage.allMyGear[0])
    theStorage.allMyGear[0].condition = "Faulty"
    theStorage.cancelEditingGear(theStorage.allMyGear[0])
    expect(theStorage.allMyGear[0].condition).to.equal("New")
  })

  it('should not change the checkedOut status of the gear', function () {
    theStorage.startEditingGear(theStorage.allMyGear[0])
    theStorage.allMyGear[0].checkedOut = true
    theStorage.cancelEditingGear(theStorage.allMyGear[0])
    expect(theStorage.allMyGear[0].checkedOut).to.equal(false)
  })
})

// FEATURE 10. Validate inputs
describe('validating inputs to a gear', function () {
  it('should not allow empty gear inputs titles, quantity, gearType, value, condition', function () {
    var theStorage = new Store()
    //title check
    theStorage.addGear('a',1, 'Building tool', 20.00, 'New')
    theStorage.addGear('',1, 'Building tool', 20.00, 'New')
    theStorage.addGear('  ',1, 'Building tool', 20.00, 'New')
    //Quantity check
    theStorage.addGear('b','', 'Building tool', 20.00, 'New')
    theStorage.addGear('c',' ', 'Building tool', 20.00, 'New')
    theStorage.addGear('d','s', 'Building tool', 20.00, 'New')
    theStorage.addGear('e',4, 'Building tool', 20.00, 'New')
    //Building Type Check
    theStorage.addGear('f',1, '', 20.00, 'New')
    theStorage.addGear('g',1, ' ', 20.00, 'New')
    //Value check
    theStorage.addGear('h',1, 'Building tool', "", 'New')
    theStorage.addGear('i',1, 'Building tool', " ", 'New')
    theStorage.addGear('j',1, 'Building tool', 20.4, 'New')
    //Condition Check
    theStorage.addGear('k',1, 'Material', 20.00, '')
    theStorage.addGear('l',1, 'Material', 20.00, ' ')
    theStorage.addGear('m',1, 'Material', 20.00, 'Old')
    const expectedGearTitles = ['a', 'e', 'j', 'm']
    const actualGearTitles = getGear(theStorage.allMyGear)
    expect(actualGearTitles).to.deep.equal(expectedGearTitles)
  })
})

// FEATURE 11. A calculation within a part
// NOT IMPLEMENTED!, therefore NOT TESTED!
/*xdescribe('a ??? calculation within a part', function () {
  xit('should do the ???? calculation correctly', function () {
    expect(true).to.equalTrue()
  })
})*/


// FEATURE 12. A calculation across many parts
describe('working out if all gear is returned', function () {
  it('should return true if all checkedOut gear is false', function () {
    var theStorage = new Store()
    expect(theStorage.isAllGearReturned()).to.be.true
  })

  it('With gear added to storage it should be true that all gear is returned and nothing is checked out', function () {
    var theStorage = new Store()
    theStorage.addGear('ceramic tiles',30, 'Material', 100.00, 'Old')
    theStorage.addGear('glue',3, 'Binding agent', 60.00, 'New')
    expect(theStorage.isAllGearReturned()).to.be.true
  })

  it('should return false for allGearReturned when gear has been checked out of storage ', function () {
    var theStorage = new Store()
    theStorage.addGear('ceramic tiles',30, 'Material', 100.00, 'Old')
    theStorage.addGear('glue',3, 'Binding agent', 60.00, 'New')
    theStorage.allMyGear[0].checkedOut = true
    theStorage.allMyGear[1].checkedOut = true
    expect(theStorage.isAllGearReturned()).to.be.false
  })
})

describe('counting stored gear', function () {
  it('should return the correct number of gear in storage as new gear is added and checked out', function () {
    var theStorage = new Store()
    expect(theStorage.getCheckedOutGearCount()).to.equal(0)
    theStorage.addGear('ceramic tiles',30, 'Material', 100.00, 'Old')
    expect(theStorage.getCheckedOutGearCount()).to.equal(0)
    theStorage.addGear('glue',3, 'Binding agent', 60.00, 'New')
    theStorage.allMyGear[0].checkedOut = true
    expect(theStorage.getCheckedOutGearCount()).to.equal(1)
    theStorage.allMyGear[1].checkedOut = true
    expect(theStorage.getCheckedOutGearCount()).to.equal(2)
    theStorage.allMyGear[0].checkedOut = false
    theStorage.allMyGear[1].checkedOut = false
    expect(theStorage.getCheckedOutGearCount()).to.equal(0)
  })
})

 // FEATURE 12. A calculation across many parts for stats of attributes
 describe('working out stats of gear', function () {
  beforeEach(function () {
    theStorage = new Store()
    theStorage.addGear('glue', 2, "Adhesive", 30.00, "Old")
    theStorage.addGear('drill', 1, "Building Tool", 150.00, "New")
    theStorage.addGear('nails', 150, "Building Equipment", 20.00, "Old")
    theStorage.addGear('wood', 30, "Building Material", 90.00, "Missing")
    theStorage.addGear('Tiles', 100, "Building Material", 180.00, "Old")
    theStorage.addGear('chainsaw', 1, "Building Tool", 120.00, "New")
    theStorage.addGear('clamps', 5, "Building Tool", 50.00, "New")
  })
  it('should output the total value of all gear owned as 640', function () {
    const actualTotalValue = theStorage.calculateTotalValue()
    const expectedTotalValue = 640
    expect(expectedTotalValue).to.deep.equal(actualTotalValue)
  })
  it('should output the total quantity of all gear owned as 289', function () {
    const actualTotalQuantity = theStorage.calculateTotalQuantity()
    const expectedTotalQuantity = 289
    expect(expectedTotalQuantity).to.deep.equal(actualTotalQuantity)
  })
})

// FEATURE 11. A calculation within a part
describe('Should be able to output correct percentages for quantity and value of gear in relation to total quantity and value in storage', function () {
  beforeEach(function () {
    theStorage = new Store()
    theStorage.addGear('glue', 2, "Adhesive", 30.00, "Old")
    theStorage.addGear('drill', 1, "Building Tool", 150.00, "New")
    theStorage.addGear('nails', 150, "Building Equipment", 20.00, "Old")
    theStorage.addGear('wood', 30, "Building Material", 90.00, "Missing")
    theStorage.addGear('Tiles', 100, "Building Material", 180.00, "Old")
  })
  it('Outputs the correct percentage for first and last piece of gears total value out of the total value in storage', function () {
    const actualPercentValuesForGear = theStorage.calculatePercentageOfGearValue()
    const actualGearOneData = actualPercentValuesForGear[0]
    const expectedDataValuesForGearOne = [ 'glue', 6.382978723404255 ]
    const actualLastPieceOfGearData = actualPercentValuesForGear[actualPercentValuesForGear.length-1]
    const expectedDataValuesForLastPieceOfGear = [  'Tiles', 38.29787234042553  ]
    expect(expectedDataValuesForGearOne).to.deep.equal(actualGearOneData)
    expect(expectedDataValuesForLastPieceOfGear).to.deep.equal(actualLastPieceOfGearData )
  })
  it('should output the correct percent for quantity of each piece of gear in relation to total quantity of gear in storage', function () {
    const actualPercentDataForQuantityOfGear = theStorage.calculatePercentageOfGearInStorage()
    const actualGearOneData = actualPercentDataForQuantityOfGear[0]
    const expectedDataForQuantityOfGearOne = [ 'glue', 0.7067137809187279 ]
    const actualLastPieceOfGearData = actualPercentDataForQuantityOfGear[actualPercentDataForQuantityOfGear.length-1]
    const expectedDataValuesForLastPieceOfGear = [  'Tiles', 35.3356890459364  ]
    expect(expectedDataForQuantityOfGearOne).to.deep.equal(actualGearOneData)
    expect(expectedDataValuesForLastPieceOfGear).to.deep.equal(actualLastPieceOfGearData)
  })
})

// FEATURE 13. Provide default values
describe('the default value for new gear', function () {
  it('should allocate a sequentially incrementing id to all new gear', function () {
    var theStorage = new Store()
    for (let expectedId = 1; expectedId < 5; expectedId += 1) {
      theStorage.addGear('Miscellanious Gear',1, 'Building Equipment', 5.00, 'New')
      var actualId = theStorage.allMyGear[theStorage.allMyGear.length - 1].id
      expect(actualId).to.equal(expectedId)
    }
  })

  it('should make sure all new gear is not checked out', function () {
    var theStorage = new Store()
    theStorage.addGear('Miscellanious Gear',1, 'Building Equipment', 5.00, 'New')
    const actualCheckedOut = theStorage.allMyGear[0].checkedOut
    expect(actualCheckedOut).to.be.false
  })

  it('when gear is added description should be automatically made and contain the title of gear', function () {
    var theStorage = new Store()
    theStorage.addGear('Saw',1, 'Building Equipment', 5.00, 'New')
    const actualDesc = theStorage.allMyGear[0].desc
    const expectedDesc = 'A Saw avaliable for check out from storage'
    expect(actualDesc).to.equal(expectedDesc)
  })
})

// FEATURE 14. Find a part given a search criterion
describe('finding gear inside storage', function () {
  it('should find nothing with an empty gear list', function () {
    var theStorage = new Store()
    const actualFoundGear = theStorage.findGear('alan key')
    expect(actualFoundGear).to.be.undefined
  })

  it('should find the only gear with a title when that title is unique', function () {
    var theStorage = new Store()
    theStorage.addGear('Alan key',1, 'Building Equipment', 10.00, 'New')
    theStorage.addGear('Bolt screws',16, 'Binding agent', 7.50, 'New')
    theStorage.addGear('Wood planks',15, 'Material', 5.00, 'New')
    const actualFoundGear = theStorage.findGear('Bolt screws')
    expect(actualFoundGear).to.exist
    const expectedFoundTitle = 'Bolt screws'
    const actualFoundTitle = actualFoundGear.title
    expect(actualFoundTitle).to.equal(expectedFoundTitle)
  })

  it('should find the first task with that title when there is more than one task with the same title', function () {
    var theStorage = new Store()
    theStorage.addGear('Alan key',1, 'Building Equipment', 10.00, 'New')
    theStorage.addGear('Bolt screws',16, 'Binding agent', 7.50, 'New')
    theStorage.addGear('Alan key',1, 'Building Equipment', 5.00, 'Old')
    theStorage.addGear('Wood planks',15, 'Material', 5.00, 'New')
    const actualFoundGear = theStorage.findGear('Alan key')
    expect(actualFoundGear).to.exist
    const expectedFoundTitle = 'Alan key'
    const actualFoundTitle = actualFoundGear.title
    expect(actualFoundTitle).to.equal(expectedFoundTitle)
    const expectedFoundId = 1
    const actualFoundId = actualFoundGear.id
    expect(actualFoundId).to.equal(expectedFoundId)
  })
})

 // FEATURE 15. Get all parts
 describe('Getting all gear from storage', function () {
    var theStorage
  beforeEach(function(){
    theStorage = new Store()
    theStorage.addGear('Alan key',1, 'Building Equipment', 10.00, 'New')
    theStorage.addGear('Bolt screws',16, 'Binding agent', 7.50, 'New')
    theStorage.addGear('Wood planks',15, 'Material', 5.00, 'New')
  })
  it('should exist and have the correct number of gear stored', function () {
    const allExistingGearInStorage = theStorage.getAllGear()
    expect(allExistingGearInStorage).to.exist
    expect(allExistingGearInStorage.length).to.equal(3)
  })

  it('getAllGear() should have the correct titles for all stored gear', function () {
    const allExistingGearInStorage = theStorage.getAllGear()
    expect(allExistingGearInStorage[0].title).to.equal('Alan key')
    expect(allExistingGearInStorage[1].title).to.equal('Bolt screws')
    expect(allExistingGearInStorage[2].title).to.equal('Wood planks')
  })

  it('getAllGear() should have the correct quantity for all stored gear', function () {
    const allExistingGearInStorage = theStorage.getAllGear()
    expect(allExistingGearInStorage[0].quantity).to.equal(1)
    expect(allExistingGearInStorage[1].quantity).to.equal(16)
    expect(allExistingGearInStorage[2].quantity).to.equal(15)
  })

  it('getAllGear() should have the correct type for all stored gear', function () {
    const allExistingGearInStorage = theStorage.getAllGear()
    expect(allExistingGearInStorage[0].gearType).to.equal('Building Equipment')
    expect(allExistingGearInStorage[1].gearType).to.equal('Binding agent')
    expect(allExistingGearInStorage[2].gearType).to.equal('Material')
  })

  it('getAllGear() should have the correct value for each piece of gear stored', function () {
    const allExistingGearInStorage = theStorage.getAllGear()
    expect(allExistingGearInStorage[0].value).to.equal(10.00)
    expect(allExistingGearInStorage[1].value).to.equal(7.50)
    expect(allExistingGearInStorage[2].value).to.equal(5.00)
  })

  it('getAllGear() should have the correct Description for each piece of gear stored', function () {
    const allExistingGearInStorage = theStorage.getAllGear()
    expect(allExistingGearInStorage[0].desc).to.equal('A Alan key avaliable for check out from storage')
    expect(allExistingGearInStorage[1].desc).to.equal('A Bolt screws avaliable for check out from storage')
    expect(allExistingGearInStorage[2].desc).to.equal('A Wood planks avaliable for check out from storage')
  })

  it('getAllGear() should have the correct CheckedOut status of false for each piece of gear stored', function () {
    const allExistingGearInStorage = theStorage.getAllGear()
    expect(allExistingGearInStorage[0].checkedOut).to.equal(false)
    expect(allExistingGearInStorage[1].checkedOut).to.equal(false)
    expect(allExistingGearInStorage[2].checkedOut).to.equal(false)
  })
})

  
})
